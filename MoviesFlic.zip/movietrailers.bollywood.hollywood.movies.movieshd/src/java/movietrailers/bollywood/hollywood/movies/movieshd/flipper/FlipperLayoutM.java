package movietrailers.bollywood.hollywood.movies.movieshd.flipper;

import android.content.Context;
import android.os.Handler;
import android.support.v7.jg;
import android.support.v7.le0;
import android.support.v7.pe0;
import android.support.v7.te0;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import androidx.viewpager.widget.ViewPager;
import java.util.Timer;
import java.util.TimerTask;

public class FlipperLayoutM extends FrameLayout implements android.support.v7.le0.a {
    public static jg h;
    public int c = 0;
    public le0 d;
    public ViewPager e;
    public int f = 2;
    public Handler g = new Handler();

    public class a implements Runnable {
        public void run() {
            if (FlipperLayoutM.this.c == FlipperLayoutM.getFlippingPagerAdapter().a()) {
                FlipperLayoutM.this.c = 0;
            }
            FlipperLayoutM.this.e.a(FlipperLayoutM.this.c = FlipperLayoutM.this.c + 1, true);
        }
    }

    public class b extends TimerTask {
        public final /* synthetic */ Runnable c;

        public b(Runnable runnable) {
            this.c = runnable;
        }

        public void run() {
            FlipperLayoutM.this.g.post(this.c);
        }
    }

    public FlipperLayoutM(Context context) {
        super(context);
        setLayout(context);
    }

    public FlipperLayoutM(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setLayout(context);
    }

    public FlipperLayoutM(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setLayout(context);
    }

    public static jg getFlippingPagerAdapter() {
        return h;
    }

    private void setLayout(Context context) {
        this.e = (ViewPager) LayoutInflater.from(context).inflate(2131558471, this, true).findViewById(2131362296);
        h = new pe0(context);
        this.e.setAdapter(h);
        this.d = new le0(this.e);
        this.d.a(this);
        this.e.a(this.d);
        a();
    }

    public final void a() {
        new Timer().schedule(new b(new a()), 500, (long) (this.f * 1000));
    }

    public void a(int i) {
        this.c = i;
    }

    public void a(te0 te0) {
        ((pe0) h).a(te0);
    }

    public int getCurrentPagePosition() {
        if (getFlippingPagerAdapter() != null) {
            return this.e.getCurrentItem() % h.a();
        }
        throw new NullPointerException("Adapter not set");
    }

    public int getScrollTimeInSec() {
        return this.f;
    }

    public void setScrollTimeInSec(int i) {
        this.f = i;
        a();
    }
}
