package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.qv;
import android.support.v7.rv;
import android.support.v7.sv;
import android.support.v7.sv.e;
import android.widget.Toast;
import com.google.android.youtube.player.YouTubePlayerView;
import movietrailers.bollywood.hollywood.movies.movieshd.classes.ApplicationClass;

public class PlayerActivityShort extends qv implements android.support.v7.sv.b {
    public sv g;
    public String h;
    public String i;
    public String j;
    public String k;
    public String l;
    public String m;
    public String n;
    public String o;
    public int p;
    public Cursor q;

    public class a implements android.support.v7.sv.d {
        public a(PlayerActivityShort playerActivityShort) {
        }

        public void a() {
        }

        public void a(android.support.v7.sv.a aVar) {
        }

        public void a(String str) {
        }

        public void b() {
        }

        public void c() {
        }

        public void d() {
        }
    }

    public class b implements android.support.v7.sv.c {
        public b(PlayerActivityShort playerActivityShort) {
        }

        public void a() {
        }

        public void a(int i) {
        }

        public void a(boolean z) {
        }

        public void b() {
        }

        public void c() {
        }
    }

    public class c implements OnClickListener {
        public final /* synthetic */ int c;
        public final /* synthetic */ int d;

        public c(int i, int i2) {
            this.c = i;
            this.d = i2;
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            if (PlayerActivityShort.this.k.equals("Movies")) {
                if (!Boolean.valueOf(MainActivity.L.c(PlayerActivityShort.this.i)).booleanValue()) {
                    try {
                        if (MainActivity.L.a(PlayerActivityShort.this.i, PlayerActivityShort.this.n, PlayerActivityShort.this.h, PlayerActivityShort.this.o, this.c, this.d)) {
                            PlayerActivityShort.this.finish();
                            return;
                        }
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
                } else if (MainActivity.L.g(PlayerActivityShort.this.i).intValue() <= 0 || !MainActivity.L.a(PlayerActivityShort.this.i, PlayerActivityShort.this.n, PlayerActivityShort.this.h, PlayerActivityShort.this.o, this.c, this.d)) {
                    return;
                }
            } else if (!PlayerActivityShort.this.k.equals("Short")) {
                return;
            } else {
                if (Boolean.valueOf(MainActivity.L.d(PlayerActivityShort.this.i)).booleanValue()) {
                    if (MainActivity.L.h(PlayerActivityShort.this.i).intValue() <= 0 || !MainActivity.L.a(PlayerActivityShort.this.i, PlayerActivityShort.this.h, PlayerActivityShort.this.j, this.c, this.d)) {
                        return;
                    }
                } else if (MainActivity.L.a(PlayerActivityShort.this.i, PlayerActivityShort.this.h, PlayerActivityShort.this.j, this.c, this.d)) {
                    PlayerActivityShort.this.finish();
                    return;
                } else {
                    return;
                }
            }
            PlayerActivityShort.this.finish();
        }
    }

    public class d implements OnClickListener {
        public void onClick(DialogInterface dialogInterface, int i) {
            PlayerActivityShort.this.finish();
        }
    }

    public void a(e eVar, rv rvVar) {
        Toast.makeText(this, "Failed to initialize.", 1).show();
    }

    /* JADX WARNING: Missing block: B:11:0x0036, code skipped:
            if (r5 == false) goto L_0x0067;
     */
    /* JADX WARNING: Missing block: B:19:0x0062, code skipped:
            if (r5 == false) goto L_0x0067;
     */
    /* JADX WARNING: Missing block: B:20:0x0065, code skipped:
            if (r5 == false) goto L_0x0067;
     */
    /* JADX WARNING: Missing block: B:21:0x0067, code skipped:
            r4.a(r2.i);
     */
    public void a(android.support.v7.sv.e r3, android.support.v7.sv r4, boolean r5) {
        /*
        r2 = this;
        r2.g = r4;
        if (r4 != 0) goto L_0x0005;
    L_0x0004:
        return;
    L_0x0005:
        r3 = r2.k;
        r0 = "Movies";
        r3 = r3.equals(r0);
        r0 = 1;
        if (r3 == 0) goto L_0x0039;
    L_0x0010:
        r3 = movietrailers.bollywood.hollywood.movies.movieshd.activities.MainActivity.L;
        r1 = r2.i;
        r3 = r3.c(r1);
        r3 = java.lang.Boolean.valueOf(r3);
        r3 = r3.booleanValue();
        if (r3 == 0) goto L_0x0036;
    L_0x0022:
        r3 = r2.l;
        r1 = r2.i;
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0036;
    L_0x002c:
        if (r5 != 0) goto L_0x0036;
    L_0x002e:
        r3 = r2.i;
        r5 = r2.p;
        r4.a(r3, r5);
        goto L_0x006c;
    L_0x0036:
        if (r5 != 0) goto L_0x006f;
    L_0x0038:
        goto L_0x0067;
    L_0x0039:
        r3 = r2.k;
        r1 = "Short";
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0065;
    L_0x0043:
        r3 = movietrailers.bollywood.hollywood.movies.movieshd.activities.MainActivity.L;
        r1 = r2.i;
        r3 = r3.d(r1);
        r3 = java.lang.Boolean.valueOf(r3);
        r3 = r3.booleanValue();
        if (r3 == 0) goto L_0x0062;
    L_0x0055:
        r3 = r2.l;
        r1 = r2.i;
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0062;
    L_0x005f:
        if (r5 != 0) goto L_0x0062;
    L_0x0061:
        goto L_0x002e;
    L_0x0062:
        if (r5 != 0) goto L_0x006f;
    L_0x0064:
        goto L_0x0067;
    L_0x0065:
        if (r5 != 0) goto L_0x006f;
    L_0x0067:
        r3 = r2.i;
        r4.a(r3);
    L_0x006c:
        r4.a(r0);
    L_0x006f:
        r3 = new movietrailers.bollywood.hollywood.movies.movieshd.activities.PlayerActivityShort$a;
        r3.<init>(r2);
        r4.a(r3);
        r3 = new movietrailers.bollywood.hollywood.movies.movieshd.activities.PlayerActivityShort$b;
        r3.<init>(r2);
        r4.a(r3);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: movietrailers.bollywood.hollywood.movies.movieshd.activities.PlayerActivityShort.a(android.support.v7.sv$e, android.support.v7.sv, boolean):void");
    }

    public final String b() {
        if (this.k.equals("Movies")) {
            this.q = MainActivity.L.k(this.i);
            while (this.q.moveToNext()) {
                this.m = this.q.getString(1);
                this.p = this.q.getInt(5);
            }
        } else if (this.k.equals("Short")) {
            this.q = MainActivity.L.l(this.i);
            while (this.q.moveToNext()) {
                this.m = this.q.getString(1);
                this.p = this.q.getInt(4);
            }
        }
        return this.m;
    }

    public void onBackPressed() {
        Dialog a;
        if (this.k.equals("Movies") || this.k.equals("Short")) {
            this.g.a();
            int b = this.g.b();
            int i = 1;
            if (b <= 0) {
                b = 1;
            }
            int c = this.g.c();
            if (c > 0) {
                i = c;
            }
            android.support.v7.h0.a aVar = new android.support.v7.h0.a(this);
            aVar.a(getString(2131820640));
            aVar.a(false);
            aVar.a(2131820715, null);
            aVar.b(2131820777, new c(b, i));
            a = aVar.a();
        } else {
            this.g.a();
            android.support.v7.h0.a aVar2 = new android.support.v7.h0.a(this);
            aVar2.a(getString(2131820640));
            aVar2.a(false);
            aVar2.a(2131820715, null);
            aVar2.b(2131820777, new d());
            a = aVar2.a();
        }
        a.show();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(2131558434);
        this.k = getIntent().getStringExtra("Type");
        this.h = getIntent().getStringExtra("videoName");
        this.i = getIntent().getStringExtra("videoUrl");
        if (this.k.equals("Short")) {
            this.j = getIntent().getStringExtra("language");
            this.l = b();
        }
        if (this.k.equals("Movies")) {
            this.n = getIntent().getStringExtra("videoThumb");
            this.o = getIntent().getStringExtra("videoDescp");
            this.l = b();
        }
        ((YouTubePlayerView) findViewById(2131362310)).a(((ApplicationClass) getApplication()).h(), this);
    }

    public void onPause() {
        super.onPause();
        this.g.a();
    }
}
