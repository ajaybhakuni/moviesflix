package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.by;
import android.support.v7.ce0;
import android.support.v7.cy;
import android.support.v7.df0;
import android.support.v7.ey;
import android.support.v7.i0;
import android.support.v7.mc0;
import android.support.v7.qy;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.material.snackbar.Snackbar;
import movietrailers.bollywood.hollywood.movies.movieshd.classes.ApplicationClass;

public class SplashScreen extends i0 {
    public static int y = 100;
    public RelativeLayout t;
    public ey u;
    public qy v;
    public ProgressBar w;
    public InterstitialAd x;

    public class a implements InterstitialAdListener {
        public void onAdClicked(Ad ad) {
        }

        public void onAdLoaded(Ad ad) {
        }

        public void onError(Ad ad, AdError adError) {
        }

        public void onInterstitialDismissed(Ad ad) {
            SplashScreen.this.p();
        }

        public void onInterstitialDisplayed(Ad ad) {
        }

        public void onLoggingImpression(Ad ad) {
        }
    }

    public class b implements qy {

        public class a implements qy {
            public void a(by byVar) {
                String str = (String) byVar.a("key_name").a(String.class);
                if (str.equals("T")) {
                    SplashScreen.this.s();
                } else if (str.equals("A")) {
                    SplashScreen.this.t();
                }
            }

            public void a(cy cyVar) {
            }
        }

        public void a(by byVar) {
            if (byVar.a()) {
                ((ApplicationClass) SplashScreen.this.getApplication()).g((String) byVar.a("mBanner").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).h((String) byVar.a("mInter").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).i((String) byVar.a("mNative").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).m((String) byVar.a("wBanner").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).n((String) byVar.a("wInter").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).o((String) byVar.a("wNative").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).p((String) byVar.a("wNativeMini").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).c((String) byVar.a("sfBanner").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).d((String) byVar.a("sfInter").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).e((String) byVar.a("sfNative").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).j((String) byVar.a("tBanner").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).k((String) byVar.a("tInter").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).l((String) byVar.a("tNative").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).a((String) byVar.a("backNative").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).f((String) byVar.a("YL").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).b((String) byVar.a("GZopUrl").a(String.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).b((Long) byVar.a("periodF").a(Long.class));
                ((ApplicationClass) SplashScreen.this.getApplication()).a((Long) byVar.a("GameZop").a(Long.class));
                SplashScreen.this.w.setVisibility(8);
                if (SplashScreen.this.x.isAdLoaded()) {
                    SplashScreen.this.x.show();
                } else {
                    SplashScreen.this.p();
                }
            }
        }

        public void a(cy cyVar) {
            ey c = new ce0(SplashScreen.this).c();
            c.a(true);
            c.b(new a());
        }
    }

    public class c implements Runnable {
        public void run() {
            if (!(SplashScreen.this.u == null || SplashScreen.this.v == null)) {
                SplashScreen.this.u.c(SplashScreen.this.v);
            }
            SplashScreen.this.w.setVisibility(8);
            SplashScreen.this.startActivity(new Intent(SplashScreen.this, MainActivity.class));
            SplashScreen.this.overridePendingTransition(2130771996, 2130771997);
            SplashScreen.this.finish();
        }
    }

    public class d implements OnClickListener {
        public void onClick(View view) {
            SplashScreen.this.q();
        }
    }

    public class e implements OnClickListener {
        public final /* synthetic */ Dialog c;

        public e(Dialog dialog) {
            this.c = dialog;
        }

        public void onClick(View view) {
            SplashScreen.this.finish();
            this.c.dismiss();
        }
    }

    public class f implements qy {

        public class a implements OnClickListener {
            public final /* synthetic */ Dialog c;
            public final /* synthetic */ df0 d;

            public a(Dialog dialog, df0 df0) {
                this.c = dialog;
                this.d = df0;
            }

            public void onClick(View view) {
                this.c.dismiss();
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setData(Uri.parse(this.d.getApp_url()));
                SplashScreen.this.startActivity(intent);
                SplashScreen.this.finish();
            }
        }

        public void a(by byVar) {
            df0 df0 = (df0) byVar.a(df0.class);
            Dialog dialog = new Dialog(SplashScreen.this);
            dialog.setContentView(2131558491);
            dialog.setCancelable(false);
            ((TextView) dialog.findViewById(2131362261)).setText(df0.getTitle());
            ((TextView) dialog.findViewById(2131361948)).setText(df0.getDescp());
            mc0.b().a(df0.getApp_thumb()).a((ImageView) dialog.findViewById(2131361870));
            ((TextView) dialog.findViewById(2131361871)).setText(df0.getApp_title());
            ((Button) dialog.findViewById(2131362286)).setOnClickListener(new a(dialog, df0));
            dialog.show();
            dialog.getWindow().setBackgroundDrawableResource(17170445);
        }

        public void a(cy cyVar) {
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(2131558437);
        r();
        this.t = (RelativeLayout) findViewById(2131362214);
        ce0.a(this, 1);
        this.w = (ProgressBar) findViewById(2131362142);
        q();
    }

    public final void p() {
        if (ce0.b(this)) {
            new Handler().postDelayed(new c(), (long) y);
            return;
        }
        Snackbar a = Snackbar.a(this.t, getResources().getString(2131820716), -2);
        a.a("RETRY", new d());
        a.h(-1);
        ((TextView) a.j().findViewById(2131362202)).setTextColor(-256);
        a.r();
    }

    public final void q() {
        this.u = new ce0(this).a();
        this.u.a(true);
        this.v = new b();
        this.u.a(this.v);
    }

    public final void r() {
        this.x = new InterstitialAd(this, getResources().getString(2131820759));
        this.x.setAdListener(new a());
        this.x.loadAd();
    }

    public final void s() {
        ey d = new ce0(this).d();
        d.a(true);
        d.b(new f());
    }

    public void t() {
        Dialog dialog = new Dialog(this);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setContentView(2131558452);
        ((TextView) dialog.findViewById(2131362245)).setText(getResources().getString(2131820673));
        ((TextView) dialog.findViewById(2131362246)).setText(getResources().getString(2131820672));
        Button button = (Button) dialog.findViewById(2131362127);
        button.setText("OK");
        button.setOnClickListener(new e(dialog));
        dialog.show();
        dialog.getWindow().setBackgroundDrawableResource(17170445);
    }
}
