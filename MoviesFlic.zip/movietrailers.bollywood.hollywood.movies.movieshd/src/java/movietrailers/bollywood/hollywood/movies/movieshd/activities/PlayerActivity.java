package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.qv;
import android.support.v7.rv;
import android.support.v7.sv;
import android.support.v7.sv.d;
import android.support.v7.sv.e;
import android.widget.Toast;
import com.google.android.youtube.player.YouTubePlayerView;
import movietrailers.bollywood.hollywood.movies.movieshd.classes.ApplicationClass;

public class PlayerActivity extends qv implements android.support.v7.sv.b {
    public sv g;
    public String h;
    public String i;
    public String j;
    public String k;
    public String l;
    public String m;
    public int n;

    public class a implements d {
        public a(PlayerActivity playerActivity) {
        }

        public void a() {
        }

        public void a(android.support.v7.sv.a aVar) {
        }

        public void a(String str) {
        }

        public void b() {
        }

        public void c() {
        }

        public void d() {
        }
    }

    public class b implements android.support.v7.sv.c {
        public b(PlayerActivity playerActivity) {
        }

        public void a() {
        }

        public void a(int i) {
        }

        public void a(boolean z) {
        }

        public void b() {
        }

        public void c() {
        }
    }

    public class c implements OnClickListener {
        public final /* synthetic */ int c;
        public final /* synthetic */ int d;

        public c(int i, int i2) {
            this.c = i;
            this.d = i2;
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            if (!Boolean.valueOf(MainActivity.L.e(PlayerActivity.this.j)).booleanValue()) {
                try {
                    if (MainActivity.L.b(PlayerActivity.this.h, PlayerActivity.this.i, PlayerActivity.this.j, PlayerActivity.this.k, this.c, this.d)) {
                        PlayerActivity.this.finish();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (MainActivity.L.i(PlayerActivity.this.j).intValue() > 0 && MainActivity.L.b(PlayerActivity.this.h, PlayerActivity.this.i, PlayerActivity.this.j, PlayerActivity.this.k, this.c, this.d)) {
                PlayerActivity.this.finish();
            }
        }
    }

    public void a(e eVar, rv rvVar) {
        Toast.makeText(this, "Failed to initialize.", 1).show();
    }

    public void a(e eVar, sv svVar, boolean z) {
        this.g = svVar;
        if (svVar != null) {
            if (Boolean.valueOf(MainActivity.L.e(this.j)).booleanValue() && this.l.equals(this.h)) {
                if (!z) {
                    svVar.a(this.h, this.n);
                }
                svVar.a(new a(this));
                svVar.a(new b(this));
            }
            if (!z) {
                svVar.a(this.h);
            }
            svVar.a(new a(this));
            svVar.a(new b(this));
            svVar.a(true);
            svVar.a(new a(this));
            svVar.a(new b(this));
        }
    }

    public final String b() {
        Cursor m = MainActivity.L.m(this.j);
        while (m.moveToNext()) {
            this.m = m.getString(1);
            this.n = m.getInt(5);
        }
        return this.m;
    }

    public void onBackPressed() {
        this.g.a();
        int b = this.g.b();
        int i = 1;
        if (b <= 0) {
            b = 1;
        }
        int c = this.g.c();
        if (c > 0) {
            i = c;
        }
        android.support.v7.h0.a aVar = new android.support.v7.h0.a(this);
        aVar.a(getString(2131820640));
        aVar.a(false);
        aVar.a(2131820715, null);
        aVar.b(2131820777, new c(b, i));
        aVar.a().show();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(2131558434);
        this.i = getIntent().getStringExtra("webSeriesName");
        this.j = getIntent().getStringExtra("webSeriesThumb");
        this.k = getIntent().getStringExtra("webSeriesLang");
        getIntent().getStringExtra("videoName");
        this.h = getIntent().getStringExtra("videoUrl");
        this.l = b();
        ((YouTubePlayerView) findViewById(2131362310)).a(((ApplicationClass) getApplication()).h(), this);
    }

    public void onPause() {
        super.onPause();
        this.g.a();
    }
}
