package movietrailers.bollywood.hollywood.movies.movieshd.classes;

import android.support.v7.jd;
import android.support.v7.kd;
import android.support.v7.sw;
import android.support.v7.xd0;

public class ApplicationClass extends kd {
    public String c;
    public String d;
    public String e;
    public String f;
    public String g;
    public String h;
    public String i;
    public String j;
    public String k;
    public String l;
    public String m;
    public String n;
    public String o;
    public String p;
    public String q;
    public String r;
    public Long s;
    public Long t;

    public String a() {
        return this.p;
    }

    public void a(Long l) {
        this.t = l;
    }

    public void a(String str) {
        this.p = str;
    }

    public String b() {
        return this.r;
    }

    public void b(Long l) {
        this.s = l;
    }

    public void b(String str) {
        this.r = str;
    }

    public Long c() {
        return this.t;
    }

    public void c(String str) {
        this.j = str;
    }

    public Long d() {
        return this.s;
    }

    public void d(String str) {
        this.k = str;
    }

    public String e() {
        return this.j;
    }

    public void e(String str) {
        this.l = str;
    }

    public String f() {
        return this.k;
    }

    public void f(String str) {
        this.q = str;
    }

    public String g() {
        return this.l;
    }

    public void g(String str) {
        this.c = str;
    }

    public String h() {
        return this.q;
    }

    public void h(String str) {
        this.d = str;
    }

    public String i() {
        return this.c;
    }

    public void i(String str) {
        this.e = str;
    }

    public String j() {
        return this.d;
    }

    public void j(String str) {
        this.m = str;
    }

    public String k() {
        return this.e;
    }

    public void k(String str) {
        this.n = str;
    }

    public String l() {
        return this.m;
    }

    public void l(String str) {
        this.o = str;
    }

    public String m() {
        return this.n;
    }

    public void m(String str) {
        this.f = str;
    }

    public String n() {
        return this.o;
    }

    public void n(String str) {
        this.g = str;
    }

    public String o() {
        return this.f;
    }

    public void o(String str) {
        this.h = str;
    }

    public void onCreate() {
        super.onCreate();
        jd.d(this);
        sw.a(this);
        xd0.a(this);
    }

    public String p() {
        return this.g;
    }

    public void p(String str) {
        this.i = str;
    }

    public String q() {
        return this.h;
    }

    public String r() {
        return this.i;
    }
}
