package movietrailers.bollywood.hollywood.movies.movieshd.firebaseservices;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingService;

public class MyFirebaseInstanceIDService extends FirebaseMessagingService {
    public void b(String str) {
        super.b(str);
        str = FirebaseInstanceId.l().b();
        FirebaseMessaging.a().a("all");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Refreshed token: ");
        stringBuilder.append(str);
        stringBuilder.toString();
    }
}
