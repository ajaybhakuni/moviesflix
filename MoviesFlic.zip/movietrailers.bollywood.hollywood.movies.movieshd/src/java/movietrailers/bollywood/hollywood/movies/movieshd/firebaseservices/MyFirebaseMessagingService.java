package movietrailers.bollywood.hollywood.movies.movieshd.firebaseservices;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.ce0;
import android.support.v7.e7.d;
import android.support.v7.mc0;
import android.support.v7.mc0.e;
import android.support.v7.n70;
import android.support.v7.vc0;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingService;
import java.util.Map;
import movietrailers.bollywood.hollywood.movies.movieshd.activities.MainActivity;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    public vc0 i = new a();

    public class a implements vc0 {
        public void a(Bitmap bitmap, e eVar) {
            MyFirebaseMessagingService.this.a(bitmap);
        }

        public void a(Drawable drawable) {
        }

        public void a(Exception exception, Drawable drawable) {
        }
    }

    public class b implements Runnable {
        public void run() {
            mc0.b().a(ce0.h).a(MyFirebaseMessagingService.this.i);
        }
    }

    public final void a(Bitmap bitmap) {
        Intent intent;
        android.support.v7.e7.b bVar = new android.support.v7.e7.b();
        bVar.b(bitmap);
        Uri defaultUri = RingtoneManager.getDefaultUri(2);
        if (ce0.i.equals("1")) {
            intent = new Intent("android.intent.action.VIEW");
            intent.setFlags(603979776);
            intent.setData(Uri.parse(ce0.j));
        } else {
            intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.setFlags(603979776);
        }
        PendingIntent activity = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
        NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
        String str = "101";
        if (VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(str, "Notification", 5);
            notificationChannel.setDescription("App Notifications");
            notificationChannel.enableLights(true);
            notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            notificationChannel.enableVibration(true);
            notificationManager.createNotificationChannel(notificationChannel);
        }
        d dVar = new d(this, str);
        dVar.e(2131689474);
        dVar.b(ce0.g);
        dVar.a(true);
        dVar.a(defaultUri);
        dVar.a(ce0.f);
        dVar.a(activity);
        dVar.a(bVar);
        dVar.b(bitmap);
        dVar.a(System.currentTimeMillis());
        dVar.d(2);
        notificationManager.notify(1, dVar.a());
    }

    public void a(n70 n70) {
        super.a(n70);
        FirebaseMessaging.a().a("all");
        if (n70.a() != null) {
            b(n70);
        }
    }

    public final void b(n70 n70) {
        Map a = n70.a();
        ce0.g = (String) a.get("title");
        ce0.f = (String) a.get("message");
        ce0.h = (String) a.get("image_uri");
        ce0.i = (String) a.get("noti_type");
        ce0.j = (String) a.get("app_url");
        if (n70.a() != null) {
            new Handler(Looper.getMainLooper()).post(new b());
        }
    }
}
