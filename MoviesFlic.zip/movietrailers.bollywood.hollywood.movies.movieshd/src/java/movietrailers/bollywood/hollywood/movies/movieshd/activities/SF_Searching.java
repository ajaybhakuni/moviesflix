package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.os.Bundle;
import android.support.v7.by;
import android.support.v7.ce0;
import android.support.v7.cy;
import android.support.v7.ee0;
import android.support.v7.i0;
import android.support.v7.qy;
import android.support.v7.td;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class SF_Searching extends i0 {
    public EditText t;
    public RecyclerView u;
    public ImageView v;
    public ArrayList<String> w;
    public ArrayList<String> x;
    public ee0 y;

    public class a implements OnClickListener {
        public void onClick(View view) {
            SF_Searching.this.onBackPressed();
            SF_Searching.this.finish();
        }
    }

    public class b implements TextWatcher {
        public void afterTextChanged(Editable editable) {
            if (editable.toString().isEmpty()) {
                SF_Searching.this.w.clear();
                SF_Searching.this.x.clear();
                SF_Searching.this.u.removeAllViews();
                return;
            }
            SF_Searching.this.a(editable.toString());
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }
    }

    public class c implements qy {
        public final /* synthetic */ String a;
        public final /* synthetic */ String b;

        public c(String str, String str2) {
            this.a = str;
            this.b = str2;
        }

        public void a(by byVar) {
            SF_Searching.this.w.clear();
            SF_Searching.this.x.clear();
            SF_Searching.this.u.removeAllViews();
            int i = 0;
            for (by byVar2 : byVar.b()) {
                String str = (String) byVar2.a("title").a(String.class);
                String str2 = (String) byVar2.a("url").a(String.class);
                if (str != null && str.toLowerCase().contains(this.a.toLowerCase())) {
                    SF_Searching.this.w.add(str);
                    SF_Searching.this.x.add(str2);
                    i++;
                }
                if (i == 15) {
                    break;
                }
            }
            SF_Searching sF_Searching = SF_Searching.this;
            sF_Searching.y = new ee0(sF_Searching, sF_Searching.w, sF_Searching.x, this.b);
            sF_Searching = SF_Searching.this;
            sF_Searching.u.setAdapter(sF_Searching.y);
        }

        public void a(cy cyVar) {
        }
    }

    public final void a(String str) {
        new ce0(this).i().b(getIntent().getStringExtra("fragmentName")).a(new c(str, getIntent().getStringExtra("lang")));
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(2131558435);
        this.v = (ImageView) findViewById(2131361879);
        this.v.setOnClickListener(new a());
        this.t = (EditText) findViewById(2131362174);
        this.t.setHint("Search Short Films");
        this.t.setFocusable(true);
        this.t.requestFocusFromTouch();
        this.u = (RecyclerView) findViewById(2131362173);
        this.u.setHasFixedSize(true);
        this.u.setLayoutManager(new LinearLayoutManager(this));
        this.u.addItemDecoration(new td(this, 1));
        this.w = new ArrayList();
        this.x = new ArrayList();
        this.t.addTextChangedListener(new b());
    }
}
