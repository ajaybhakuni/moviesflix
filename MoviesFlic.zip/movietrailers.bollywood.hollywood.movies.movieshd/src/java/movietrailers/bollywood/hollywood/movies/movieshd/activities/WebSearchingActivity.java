package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.os.Bundle;
import android.support.v7.by;
import android.support.v7.ce0;
import android.support.v7.cy;
import android.support.v7.i0;
import android.support.v7.ie0;
import android.support.v7.qy;
import android.support.v7.td;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class WebSearchingActivity extends i0 {
    public EditText t;
    public RecyclerView u;
    public ImageView v;
    public ArrayList<String> w;
    public ArrayList<String> x;
    public ArrayList<String> y;
    public ie0 z;

    public class a implements OnClickListener {
        public void onClick(View view) {
            WebSearchingActivity.this.onBackPressed();
            WebSearchingActivity.this.finish();
        }
    }

    public class b implements TextWatcher {
        public void afterTextChanged(Editable editable) {
            if (editable.toString().isEmpty()) {
                WebSearchingActivity.this.x.clear();
                WebSearchingActivity.this.w.clear();
                WebSearchingActivity.this.y.clear();
                WebSearchingActivity.this.u.removeAllViews();
                return;
            }
            WebSearchingActivity.this.a(editable.toString());
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }
    }

    public class c implements qy {
        public final /* synthetic */ String a;

        public c(String str) {
            this.a = str;
        }

        public void a(by byVar) {
            WebSearchingActivity.this.x.clear();
            WebSearchingActivity.this.w.clear();
            WebSearchingActivity.this.y.clear();
            WebSearchingActivity.this.u.removeAllViews();
            int i = 0;
            for (by byVar2 : byVar.b()) {
                String str = (String) byVar2.a("webTitle").a(String.class);
                String str2 = (String) byVar2.a("webLang").a(String.class);
                String str3 = (String) byVar2.a("webThumb").a(String.class);
                if (str != null && str.toLowerCase().contains(this.a.toLowerCase())) {
                    WebSearchingActivity.this.x.add(str2);
                    WebSearchingActivity.this.w.add(str);
                    WebSearchingActivity.this.y.add(str3);
                    i++;
                }
                if (i == 15) {
                    break;
                }
            }
            WebSearchingActivity webSearchingActivity = WebSearchingActivity.this;
            webSearchingActivity.z = new ie0(webSearchingActivity, webSearchingActivity.x, webSearchingActivity.w, webSearchingActivity.y);
            webSearchingActivity = WebSearchingActivity.this;
            webSearchingActivity.u.setAdapter(webSearchingActivity.z);
        }

        public void a(cy cyVar) {
        }
    }

    public final void a(String str) {
        new ce0(this).h().b(getIntent().getStringExtra("fragmentName")).a(new c(str));
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(2131558435);
        this.v = (ImageView) findViewById(2131361879);
        this.v.setOnClickListener(new a());
        this.t = (EditText) findViewById(2131362174);
        this.t.setHint("Search Web Series");
        this.t.setFocusable(true);
        this.t.requestFocusFromTouch();
        this.u = (RecyclerView) findViewById(2131362173);
        this.u.setHasFixedSize(true);
        this.u.setLayoutManager(new LinearLayoutManager(this));
        this.u.addItemDecoration(new td(this, 1));
        this.x = new ArrayList();
        this.w = new ArrayList();
        this.y = new ArrayList();
        this.t.addTextChangedListener(new b());
    }
}
