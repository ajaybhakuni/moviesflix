package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.ay;
import android.support.v7.by;
import android.support.v7.ce0;
import android.support.v7.cy;
import android.support.v7.ey;
import android.support.v7.i0;
import android.support.v7.jf0;
import android.support.v7.mc0;
import android.support.v7.qc0;
import android.support.v7.ze0;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.d0;
import androidx.recyclerview.widget.RecyclerView.g;
import com.facebook.ads.Ad;
import com.facebook.ads.AdChoicesView;
import com.facebook.ads.AdError;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import java.util.ArrayList;
import movietrailers.bollywood.hollywood.movies.movieshd.classes.ApplicationClass;

public class WebSeriesDetail extends i0 {
    public TextView A;
    public String B;
    public String C;
    public String D;
    public String E;
    public String F;
    public int G;
    public int H;
    public String I;
    public CardView J;
    public RecyclerView t;
    public ey u;
    public ProgressBar v;
    public ArrayList<jf0> w = new ArrayList();
    public ImageView x;
    public NativeAd y;
    public TextView z;

    public class a implements OnClickListener {
        public void onClick(View view) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("https://www.youtube.com/watch?v=");
            stringBuilder.append(WebSeriesDetail.this.I);
            String stringBuilder2 = stringBuilder.toString();
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(stringBuilder2));
            WebSeriesDetail.this.startActivity(intent);
        }
    }

    public class b implements ay {
        public void a(by byVar) {
        }

        public void a(by byVar, String str) {
        }

        public void a(cy cyVar) {
        }

        public void b(by byVar, String str) {
        }

        public void c(by byVar, String str) {
            jf0 jf0 = (jf0) byVar.a(jf0.class);
            WebSeriesDetail.this.v.setVisibility(4);
            int parseInt = Integer.parseInt(byVar.c());
            if (parseInt == 1) {
                WebSeriesDetail.this.I = jf0.getWebThumb();
                WebSeriesDetail.this.J.setVisibility(0);
            }
            if (parseInt % 5 == 0) {
                WebSeriesDetail.this.w.add(null);
            }
            WebSeriesDetail.this.w.add(jf0);
            WebSeriesDetail webSeriesDetail = WebSeriesDetail.this;
            c cVar = new c(webSeriesDetail, webSeriesDetail.w);
            WebSeriesDetail.this.t.setAdapter(cVar);
            cVar.d();
        }
    }

    public class c extends g<e> {
        public ArrayList<jf0> c;
        public Context d;
        public int e = 0;
        public int f = 1;

        public class a implements OnClickListener {
            public final /* synthetic */ jf0 c;

            public a(jf0 jf0) {
                this.c = jf0;
            }

            public void onClick(View view) {
                String webThumb = this.c.getWebThumb();
                String webTitle = this.c.getWebTitle();
                this.c.getWebLang();
                Intent intent = new Intent(WebSeriesDetail.this, DetailActivity.class);
                intent.putExtra("webSeriesLang", WebSeriesDetail.this.D);
                intent.putExtra("webSeriesName", WebSeriesDetail.this.B);
                intent.putExtra("webSeriesThumb", WebSeriesDetail.this.C);
                intent.putExtra("videoUrl", webThumb);
                intent.putExtra("videoName", webTitle);
                WebSeriesDetail.this.startActivity(intent);
                if (ce0.c(c.this.d) && ze0.q0.isAdLoaded()) {
                    ze0.q0.show();
                    ce0.a(c.this.d, Long.valueOf(System.currentTimeMillis()));
                }
            }
        }

        public class b implements NativeAdListener {
            public final /* synthetic */ c a;

            public b(c cVar) {
                this.a = cVar;
            }

            public void onAdClicked(Ad ad) {
            }

            public void onAdLoaded(Ad ad) {
                if (WebSeriesDetail.this.y != null && WebSeriesDetail.this.y == ad) {
                    if (WebSeriesDetail.this.y != null) {
                        WebSeriesDetail.this.y.unregisterView();
                    }
                    this.a.x.setText(WebSeriesDetail.this.y.getAdSocialContext());
                    this.a.y.setText(WebSeriesDetail.this.y.getAdCallToAction());
                    this.a.A.setText(WebSeriesDetail.this.y.getAdCallToAction());
                    WebSeriesDetail webSeriesDetail = WebSeriesDetail.this;
                    this.a.w.addView(new AdChoicesView(webSeriesDetail, webSeriesDetail.y, true));
                    ArrayList arrayList = new ArrayList();
                    arrayList.add(this.a.w);
                    arrayList.add(this.a.z);
                    arrayList.add(this.a.A);
                    WebSeriesDetail.this.y.registerViewForInteraction(this.a.v, this.a.z, arrayList);
                }
            }

            public void onError(Ad ad, AdError adError) {
            }

            public void onLoggingImpression(Ad ad) {
            }

            public void onMediaDownloaded(Ad ad) {
            }
        }

        public class e extends d0 {
            public e(c cVar, View view) {
                super(view);
            }
        }

        public class c extends e {
            public Button A;
            public RelativeLayout v;
            public LinearLayout w;
            public TextView x;
            public TextView y;
            public MediaView z;

            public c(c cVar, View view) {
                super(cVar, view);
                this.v = (RelativeLayout) view.findViewById(2131362111);
                this.w = (LinearLayout) view.findViewById(2131361858);
                this.x = (TextView) view.findViewById(2131362114);
                this.y = (TextView) view.findViewById(2131362109);
                this.z = (MediaView) view.findViewById(2131362113);
                this.A = (Button) view.findViewById(2131362110);
            }
        }

        public class d extends e {
            public View v;
            public CardView w = ((CardView) this.v.findViewById(2131361939));
            public ProgressBar x = ((ProgressBar) this.v.findViewById(2131361934));
            public TextView y = ((TextView) this.v.findViewById(2131362061));

            public d(c cVar, View view) {
                super(cVar, view);
                this.v = view;
            }

            public void a(String str) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("https://img.youtube.com/vi/");
                stringBuilder.append(str);
                stringBuilder.append("/hqdefault.jpg");
                str = stringBuilder.toString();
                ImageView imageView = (ImageView) this.v.findViewById(2131362060);
                qc0 a = mc0.b().a(str);
                a.a(2131230965);
                a.a(imageView);
            }
        }

        public c(Context context, ArrayList<jf0> arrayList) {
            this.d = context;
            this.c = arrayList;
        }

        public int a() {
            return this.c.size();
        }

        /* renamed from: a */
        public void b(e eVar, int i) {
            if (eVar.i() == this.e) {
                jf0 jf0 = (jf0) this.c.get(i);
                d dVar = (d) eVar;
                Boolean valueOf = Boolean.valueOf(MainActivity.L.e(WebSeriesDetail.this.C));
                WebSeriesDetail webSeriesDetail = WebSeriesDetail.this;
                webSeriesDetail.E = webSeriesDetail.r();
                if (valueOf.booleanValue() && WebSeriesDetail.this.E.equals(jf0.getWebThumb())) {
                    dVar.x.setVisibility(0);
                    dVar.w.setVisibility(0);
                    dVar.x.setProgress(Math.round((float) ((WebSeriesDetail.this.G * 100) / WebSeriesDetail.this.H)));
                } else {
                    dVar.x.setVisibility(8);
                    dVar.w.setVisibility(8);
                }
                dVar.y.setText(jf0.getWebTitle());
                dVar.y.setSelected(true);
                dVar.a(jf0.getWebThumb());
                dVar.v.setOnClickListener(new a(jf0));
            } else if (eVar.i() == this.f) {
                c cVar = (c) eVar;
                WebSeriesDetail webSeriesDetail2 = WebSeriesDetail.this;
                webSeriesDetail2.y = new NativeAd(webSeriesDetail2, ((ApplicationClass) webSeriesDetail2.getApplication()).r());
                WebSeriesDetail.this.y.setAdListener(new b(cVar));
                WebSeriesDetail.this.y.loadAd();
            }
        }

        public int b(int i) {
            return this.c.get(i) == null ? this.f : this.e;
        }

        public e b(ViewGroup viewGroup, int i) {
            return i == this.e ? new d(this, LayoutInflater.from(viewGroup.getContext()).inflate(2131558544, viewGroup, false)) : i == this.f ? new c(this, LayoutInflater.from(viewGroup.getContext()).inflate(2131558439, viewGroup, false)) : null;
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(2131558438);
        q();
        this.v = (ProgressBar) findViewById(2131362063);
        this.v.setVisibility(0);
        this.B = getIntent().getStringExtra("webSeriesName");
        this.C = getIntent().getStringExtra("webSeriesThumb");
        this.D = getIntent().getStringExtra("webSeriesLang");
        qc0 a = mc0.b().a(this.C);
        a.a(2131230965);
        a.a(this.x);
        this.z.setText(this.B);
        this.A.setText(this.D);
        this.u = new ce0(this).h().b(this.B);
        this.u.a(true);
        this.t = (RecyclerView) findViewById(2131362301);
        this.t.hasFixedSize();
        this.t.setNestedScrollingEnabled(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.a(true);
        linearLayoutManager.b(true);
        this.t.setLayoutManager(linearLayoutManager);
        p();
        this.J = (CardView) findViewById(2131362295);
        this.J.setOnClickListener(new a());
    }

    public void onRestart() {
        super.onRestart();
        p();
    }

    public final void p() {
        this.w.clear();
        this.u.a(new b());
    }

    public void q() {
        this.x = (ImageView) findViewById(2131362299);
        this.z = (TextView) findViewById(2131362306);
        this.A = (TextView) findViewById(2131362298);
    }

    public final String r() {
        Cursor m = MainActivity.L.m(this.C);
        while (m.moveToNext()) {
            this.F = m.getString(1);
            this.G = m.getInt(5);
            this.H = m.getInt(6);
        }
        return this.F;
    }
}
