package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.content.res.TypedArray;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v7.ae0;
import android.support.v7.be0;
import android.support.v7.cd0;
import android.support.v7.ce0;
import android.support.v7.dd0;
import android.support.v7.dv;
import android.support.v7.ge0;
import android.support.v7.he0;
import android.support.v7.i0;
import android.support.v7.je0;
import android.support.v7.k7;
import android.support.v7.rt;
import android.support.v7.st;
import android.support.v7.tt;
import android.support.v7.wd0;
import android.support.v7.yd0;
import android.support.v7.zd0;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.UnderlineSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ViewFlipper;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdBase.NativeComponentTag;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.github.florent37.bubbletab.BubbleTab;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.iid.FirebaseInstanceId;
import java.util.ArrayList;
import java.util.Arrays;
import movietrailers.bollywood.hollywood.movies.movieshd.classes.ApplicationClass;

public class MainActivity extends i0 implements android.support.v7.ae0.a {
    public static ViewPager J;
    public static ge0 K;
    public static yd0 L;
    public static MenuItem M;
    public static InterstitialAd N;
    public AdView A;
    public RelativeLayout B;
    public st C;
    public LinearLayout D;
    public NativeAdLayout E;
    public NativeAd F;
    public AdOptionsView G;
    public MediaView H;
    public TextView I;
    public String[] t;
    public Drawable[] u;
    public cd0 v;
    public BubbleTab w;
    public Toolbar x;
    public RecyclerView y;
    public ViewFlipper z;

    public class a implements OnClickListener {
        public final /* synthetic */ Dialog c;

        public a(Dialog dialog) {
            this.c = dialog;
        }

        public void onClick(View view) {
            this.c.dismiss();
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(MainActivity.this.getResources().getString(2131820766)));
            MainActivity.this.startActivity(intent);
        }
    }

    public class b implements InterstitialAdListener {
        public b(MainActivity mainActivity) {
        }

        public void onAdClicked(Ad ad) {
        }

        public void onAdLoaded(Ad ad) {
        }

        public void onError(Ad ad, AdError adError) {
        }

        public void onInterstitialDismissed(Ad ad) {
            MainActivity.N.loadAd();
        }

        public void onInterstitialDisplayed(Ad ad) {
        }

        public void onLoggingImpression(Ad ad) {
        }
    }

    public class c implements androidx.viewpager.widget.ViewPager.j {
        public c(MainActivity mainActivity) {
        }

        public void a(int i) {
        }

        public void a(int i, float f, int i2) {
        }

        public void b(int i) {
        }
    }

    public class d implements AdListener {
        public void onAdClicked(Ad ad) {
        }

        public void onAdLoaded(Ad ad) {
            MainActivity.this.I.setVisibility(8);
        }

        public void onError(Ad ad, AdError adError) {
            MainActivity.this.I.setVisibility(0);
        }

        public void onLoggingImpression(Ad ad) {
        }
    }

    public class e extends ClickableSpan {
        public void onClick(View view) {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse("https://developers.google.com/youtube/branding_guidelines"));
            MainActivity.this.startActivity(intent);
        }

        public void updateDrawState(TextPaint textPaint) {
            super.updateDrawState(textPaint);
            textPaint.setUnderlineText(false);
        }
    }

    public class f implements OnClickListener {
        public final /* synthetic */ Dialog c;

        public f(MainActivity mainActivity, Dialog dialog) {
            this.c = dialog;
        }

        public void onClick(View view) {
            this.c.dismiss();
        }
    }

    public class g implements dv<rt> {
        @SuppressLint({"WrongConstant"})
        public void a(rt rtVar) {
            if (rtVar.i() == 2 && rtVar.a(1)) {
                try {
                    MainActivity.this.C.a(rtVar, 1, MainActivity.this, 17326);
                } catch (SendIntentException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public class h implements dv<rt> {
        @SuppressLint({"WrongConstant"})
        public void a(rt rtVar) {
            if (rtVar.i() == 3) {
                try {
                    MainActivity.this.C.a(rtVar, 1, MainActivity.this, 17326);
                } catch (SendIntentException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public class i implements NativeAdListener {
        public final /* synthetic */ ProgressBar a;
        public final /* synthetic */ LinearLayout b;

        public i(ProgressBar progressBar, LinearLayout linearLayout) {
            this.a = progressBar;
            this.b = linearLayout;
        }

        public void onAdClicked(Ad ad) {
            this.a.setVisibility(8);
        }

        public void onAdLoaded(Ad ad) {
            this.a.setVisibility(8);
            this.b.setVisibility(0);
            if (MainActivity.this.F != null && MainActivity.this.F == ad && MainActivity.this.E != null) {
                MainActivity mainActivity;
                MainActivity.this.F.unregisterView();
                if (MainActivity.this.D != null) {
                    mainActivity = MainActivity.this;
                    mainActivity.G = new AdOptionsView(mainActivity, mainActivity.F, MainActivity.this.E);
                    MainActivity.this.D.removeAllViews();
                    MainActivity.this.D.addView(MainActivity.this.G, 0);
                }
                mainActivity = MainActivity.this;
                mainActivity.a(mainActivity.F, (View) MainActivity.this.E);
            }
        }

        public void onError(Ad ad, AdError adError) {
            MainActivity.this.E.setVisibility(8);
            this.a.setVisibility(8);
            this.b.setVisibility(0);
        }

        public void onLoggingImpression(Ad ad) {
        }

        public void onMediaDownloaded(Ad ad) {
        }
    }

    public class j implements OnClickListener {
        public final /* synthetic */ Dialog c;

        public j(Dialog dialog) {
            this.c = dialog;
        }

        public void onClick(View view) {
            this.c.dismiss();
            MainActivity.this.finish();
        }
    }

    public void a(int i) {
        this.v.a();
        if (i == 0) {
            J.setCurrentItem(0);
            return;
        }
        int i2 = 1;
        if (i != 1) {
            i2 = 2;
            if (i != 2) {
                i2 = 3;
                if (i != 3) {
                    i2 = 4;
                    if (i != 4) {
                        Intent intent;
                        String string;
                        String str = "android.intent.action.VIEW";
                        if (i == 5) {
                            intent = new Intent(str);
                            string = getResources().getString(2131820766);
                        } else if (i == 6) {
                            intent = new Intent(str);
                            string = getString(2131820632);
                        } else {
                            StringBuilder stringBuilder;
                            String str2;
                            if (i == 7) {
                                intent = new Intent("android.intent.action.SEND");
                                intent.setType("text/plain");
                                intent.putExtra("android.intent.extra.SUBJECT", getResources().getString(2131820577));
                                stringBuilder = new StringBuilder();
                                str2 = "\n";
                                stringBuilder.append(str2);
                                stringBuilder.append(getResources().getString(2131820754));
                                stringBuilder.append(str2);
                                string = stringBuilder.toString();
                                StringBuilder stringBuilder2 = new StringBuilder();
                                stringBuilder2.append(string);
                                stringBuilder2.append(getString(2131820766));
                                intent.putExtra("android.intent.extra.TEXT", stringBuilder2.toString());
                                intent = Intent.createChooser(intent, "choose one");
                            } else if (i == 8) {
                                intent = new Intent(str);
                                string = getResources().getString(2131820727);
                            } else if (i == 9) {
                                if (VERSION.SDK_INT >= 26) {
                                    intent = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
                                    intent.putExtra("android.provider.extra.APP_PACKAGE", getPackageName());
                                } else {
                                    intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("package:");
                                    stringBuilder.append(getPackageName());
                                    string = stringBuilder.toString();
                                }
                            } else if (i == 10) {
                                Dialog dialog = new Dialog(this);
                                dialog.setContentView(2131558469);
                                dialog.setCancelable(false);
                                ((TextView) dialog.findViewById(2131362245)).setText(getResources().getString(2131820577));
                                str2 = getResources().getString(2131820633);
                                SpannableString spannableString = new SpannableString(str2);
                                spannableString.setSpan(new e(), 366, 424, 33);
                                spannableString.setSpan(new UnderlineSpan(), str2.indexOf(getResources().getString(2131820778)), str2.indexOf(getResources().getString(2131820778)) + String.valueOf(getResources().getString(2131820778)).length(), 33);
                                TextView textView = (TextView) dialog.findViewById(2131362246);
                                textView.setText(spannableString);
                                textView.setMovementMethod(LinkMovementMethod.getInstance());
                                textView.setHighlightColor(0);
                                Button button = (Button) dialog.findViewById(2131362127);
                                button.setText("Agree");
                                button.setOnClickListener(new f(this, dialog));
                                dialog.show();
                                dialog.getWindow().setBackgroundDrawableResource(17170445);
                                return;
                            } else {
                                return;
                            }
                            startActivity(intent);
                            return;
                        }
                        intent.setData(Uri.parse(string));
                        startActivity(intent);
                        return;
                    }
                }
            }
        }
        J.setCurrentItem(i2);
    }

    public final void a(NativeAd nativeAd, View view) {
        MediaView mediaView = (MediaView) view.findViewById(2131362112);
        TextView textView = (TextView) view.findViewById(2131362116);
        TextView textView2 = (TextView) view.findViewById(2131362109);
        TextView textView3 = (TextView) view.findViewById(2131362115);
        TextView textView4 = (TextView) view.findViewById(2131362114);
        Button button = (Button) view.findViewById(2131362110);
        this.H = (MediaView) view.findViewById(2131362113);
        textView4.setText(nativeAd.getAdSocialContext());
        button.setText(nativeAd.getAdCallToAction());
        button.setVisibility(nativeAd.hasCallToAction() ? 0 : 4);
        textView.setText(nativeAd.getAdvertiserName());
        textView2.setText(nativeAd.getAdBodyText());
        textView3.setText(2131820760);
        ArrayList arrayList = new ArrayList();
        arrayList.add(mediaView);
        arrayList.add(this.H);
        arrayList.add(button);
        nativeAd.registerViewForInteraction(this.E, this.H, mediaView, arrayList);
        NativeComponentTag.tagView(mediaView, NativeComponentTag.AD_ICON);
        NativeComponentTag.tagView(textView, NativeComponentTag.AD_TITLE);
        NativeComponentTag.tagView(textView2, NativeComponentTag.AD_BODY);
        NativeComponentTag.tagView(textView4, NativeComponentTag.AD_SOCIAL_CONTEXT);
        NativeComponentTag.tagView(button, NativeComponentTag.AD_CALL_TO_ACTION);
    }

    public final int d(int i) {
        return k7.a(this, i);
    }

    public final be0 e(int i) {
        he0 he0 = new he0(this.u[i], this.t[i]);
        he0.a(d(2131099699));
        he0.d(d(2131099699));
        he0.b(d(2131099698));
        he0.c(d(2131099698));
        return he0;
    }

    public void f(int i) {
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(i);
        imageView.setScaleType(ScaleType.FIT_XY);
        this.z = (ViewFlipper) findViewById(2131361987);
        this.z.addView(imageView);
        this.z.setFlipInterval(3000);
        this.z.setAutoStart(true);
        this.z.setInAnimation(this, 17432578);
        this.z.setOutAnimation(this, 17432579);
    }

    public void onBackPressed() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(2131558470);
        dialog.setCanceledOnTouchOutside(false);
        ProgressBar progressBar = (ProgressBar) dialog.findViewById(2131361973);
        LinearLayout linearLayout = (LinearLayout) dialog.findViewById(2131361897);
        progressBar.setVisibility(0);
        this.E = (NativeAdLayout) dialog.findViewById(2131362111);
        this.D = (LinearLayout) dialog.findViewById(2131361858);
        this.F = new NativeAd(this, ((ApplicationClass) getApplication()).a());
        this.F.setAdListener(new i(progressBar, linearLayout));
        this.F.loadAd();
        CardView cardView = (CardView) dialog.findViewById(2131362151);
        ((CardView) dialog.findViewById(2131361984)).setOnClickListener(new j(dialog));
        cardView.setOnClickListener(new a(dialog));
        dialog.show();
        dialog.getWindow().setBackgroundDrawableResource(17170445);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(2131558431);
        N = new InterstitialAd(this, ((ApplicationClass) getApplication()).j());
        N.setAdListener(new b(this));
        N.loadAd();
        p();
        FirebaseAnalytics.getInstance(this);
        String b = FirebaseInstanceId.l().b();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onCreate: ");
        stringBuilder.append(b);
        stringBuilder.toString();
        L = new yd0(this);
        t();
        zd0.a(this);
        if (ce0.a(this) == 1) {
            wd0.a(this);
            ce0.a(this, 0);
        }
        this.B = (RelativeLayout) findViewById(2131361857);
        q();
        AnimationDrawable animationDrawable = (AnimationDrawable) this.x.getBackground();
        a(this.x);
        J.a(true, new je0());
        K = new ge0(h(), this);
        J.setAdapter(K);
        J.setOnPageChangeListener(new c(this));
        this.w.setupWithViewPager(J);
        dd0 dd0 = new dd0(this);
        dd0.a(this.x);
        dd0.b(false);
        dd0.a(false);
        dd0.a(bundle);
        dd0.b(2131558484);
        this.v = dd0.c();
        for (int f : new int[]{2131230893, 2131230820, 2131230976, 2131230830, 2131230890, 2131230970}) {
            f(f);
        }
        this.u = r();
        this.t = s();
        r3 = new be0[11];
        be0 e = e(0);
        e.a(true);
        r3[0] = e;
        r3[1] = e(1);
        r3[2] = e(2);
        r3[3] = e(3);
        r3[4] = e(4);
        r3[5] = e(5);
        r3[6] = e(6);
        r3[7] = e(7);
        r3[8] = e(8);
        r3[9] = e(9);
        r3[10] = e(10);
        ae0 ae0 = new ae0(Arrays.asList(r3));
        ae0.a(this);
        this.y = (RecyclerView) findViewById(2131362058);
        this.y.setNestedScrollingEnabled(false);
        this.y.setLayoutManager(new LinearLayoutManager(this));
        this.y.setAdapter(ae0);
        ae0.d(0);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(2131623937, menu);
        M = menu.findItem(2131361998);
        if (((ApplicationClass) getApplication()).c().longValue() == 0) {
            M.setVisible(false);
        }
        return true;
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 2131361998) {
            return super.onOptionsItemSelected(menuItem);
        }
        startActivity(new Intent(this, Gaming.class));
        if (ce0.c(this) && N.isAdLoaded()) {
            N.show();
            ce0.a(this, Long.valueOf(System.currentTimeMillis()));
        }
        return true;
    }

    public void onResume() {
        super.onResume();
        this.C.a().a(new h());
    }

    public final void p() {
        this.C = tt.a(this);
        this.C.a().a(new g());
    }

    public final void q() {
        this.A = new AdView(this, ((ApplicationClass) getApplication()).i(), AdSize.BANNER_HEIGHT_50);
        this.B.removeAllViews();
        this.B.addView(this.A);
        this.A.setAdListener(new d());
        this.A.loadAd();
    }

    public final Drawable[] r() {
        TypedArray obtainTypedArray = getResources().obtainTypedArray(2130903040);
        Drawable[] drawableArr = new Drawable[obtainTypedArray.length()];
        for (int i = 0; i < obtainTypedArray.length(); i++) {
            int resourceId = obtainTypedArray.getResourceId(i, 0);
            if (resourceId != 0) {
                drawableArr[i] = k7.c(this, resourceId);
            }
        }
        obtainTypedArray.recycle();
        return drawableArr;
    }

    public final String[] s() {
        return getResources().getStringArray(2130903041);
    }

    public void t() {
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(2131362108);
        this.x = (Toolbar) findViewById(2131362264);
        J = (ViewPager) findViewById(2131362066);
        this.w = (BubbleTab) findViewById(2131362067);
        this.I = (TextView) findViewById(2131361880);
    }
}
