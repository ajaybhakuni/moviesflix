package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.af0;
import android.support.v7.ay;
import android.support.v7.by;
import android.support.v7.ce0;
import android.support.v7.cy;
import android.support.v7.ey;
import android.support.v7.i0;
import android.support.v7.mc0;
import android.support.v7.nb0;
import android.support.v7.qc0;
import android.support.v7.se0;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.like.LikeButton;
import movietrailers.bollywood.hollywood.movies.movieshd.flipper.FlipperLayoutAd;

public class DetailActivity extends i0 {
    public String A;
    public FlipperLayoutAd B;
    public TextView t;
    public TextView u;
    public RelativeLayout v;
    public ImageView w;
    public LikeButton x;
    public String y;
    public String z;

    public class a implements OnClickListener {
        public void onClick(View view) {
            DetailActivity.this.onBackPressed();
        }
    }

    public class b implements OnClickListener {
        public void onClick(View view) {
            String str = "android.intent.action.VIEW";
            Intent intent = new Intent(str, Uri.parse("http://instagram.com/_u/movieflix_entertainment"));
            intent.setPackage("com.instagram.android");
            try {
                DetailActivity.this.startActivity(intent);
            } catch (ActivityNotFoundException unused) {
                DetailActivity.this.startActivity(new Intent(str, Uri.parse("http://instagram.com/movieflix_entertainment")));
            }
        }
    }

    public class c implements OnClickListener {
        public final /* synthetic */ String c;
        public final /* synthetic */ String d;

        public c(String str, String str2) {
            this.c = str;
            this.d = str2;
        }

        public void onClick(View view) {
            Intent intent = new Intent(DetailActivity.this, PlayerActivity.class);
            intent.putExtra("webSeriesLang", DetailActivity.this.A);
            intent.putExtra("webSeriesName", DetailActivity.this.y);
            intent.putExtra("webSeriesThumb", DetailActivity.this.z);
            intent.putExtra("videoUrl", this.c);
            intent.putExtra("videoName", this.d);
            DetailActivity.this.startActivity(intent);
            DetailActivity.this.finish();
        }
    }

    public class d implements nb0 {
        public final /* synthetic */ String a;
        public final /* synthetic */ String b;
        public final /* synthetic */ String c;

        public d(String str, String str2, String str3) {
            this.a = str;
            this.b = str2;
            this.c = str3;
        }

        public void a(LikeButton likeButton) {
            if (DetailActivity.this.a(this.a)) {
                DetailActivity detailActivity = DetailActivity.this;
                detailActivity.x.setLikeDrawable(detailActivity.getResources().getDrawable(2131230922));
            }
            DetailActivity.this.x.setLiked(Boolean.valueOf(false));
            if (MainActivity.L.f(this.a).intValue() > 0) {
                Toast.makeText(DetailActivity.this, "Removed from Favourite", 0).show();
            }
        }

        public void b(LikeButton likeButton) {
            if (!DetailActivity.this.a(this.a)) {
                DetailActivity detailActivity = DetailActivity.this;
                detailActivity.x.setLikeDrawable(detailActivity.getResources().getDrawable(2131230921));
                DetailActivity.this.x.setLiked(Boolean.valueOf(true));
                try {
                    (MainActivity.L.a(this.a, this.b, this.c, DetailActivity.this.y, DetailActivity.this.z, "Web", "", "") ? Toast.makeText(DetailActivity.this, "Added to Favourite", 0) : Toast.makeText(DetailActivity.this, "Not Added to Favourite", 0)).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public class e implements ay {

        public class a implements android.support.v7.se0.b {
            public final /* synthetic */ af0 a;

            public a(af0 af0) {
                this.a = af0;
            }

            public void a(se0 se0) {
                try {
                    DetailActivity detailActivity = DetailActivity.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("market://details?id=");
                    stringBuilder.append(this.a.getFlipAdUrl());
                    detailActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(stringBuilder.toString())));
                } catch (ActivityNotFoundException unused) {
                }
            }
        }

        public void a(by byVar) {
        }

        public void a(by byVar, String str) {
        }

        public void a(cy cyVar) {
        }

        public void b(by byVar, String str) {
        }

        public void c(by byVar, String str) {
            af0 af0 = (af0) byVar.a(af0.class);
            se0 se0 = new se0(DetailActivity.this);
            se0.c(String.valueOf(af0.getFlipAdThumb()));
            se0.a(ScaleType.FIT_XY);
            se0.a(af0.getFlipAdDescp());
            se0.b(af0.getFlipAdName());
            se0.d(af0.getS1());
            se0.e(af0.getS2());
            se0.f(af0.getS3());
            se0.g(af0.getS4());
            DetailActivity.this.B.a(se0);
            se0.a(new a(af0));
        }
    }

    public final boolean a(String str) {
        return Boolean.valueOf(MainActivity.L.b(str)).booleanValue();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(2131558428);
        this.B = (FlipperLayoutAd) findViewById(2131361988);
        this.y = getIntent().getStringExtra("webSeriesName");
        this.z = getIntent().getStringExtra("webSeriesThumb");
        String str = "webSeriesLang";
        this.A = getIntent().getStringExtra(str);
        String str2 = "videoName";
        getIntent().getStringExtra(str2);
        String str3 = "videoUrl";
        getIntent().getStringExtra(str3);
        p();
        this.t = (TextView) findViewById(2131362291);
        this.u = (TextView) findViewById(2131362268);
        String stringExtra = getIntent().getStringExtra(str2);
        this.t.setText(stringExtra);
        this.t.setSelected(true);
        this.u.setText(stringExtra);
        str = getIntent().getStringExtra(str);
        this.x = (LikeButton) findViewById(2131361978);
        this.w = (ImageView) findViewById(2131361876);
        this.w.setOnClickListener(new a());
        str2 = getIntent().getStringExtra(str3);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("https://img.youtube.com/vi/");
        stringBuilder.append(str2);
        stringBuilder.append("/hqdefault.jpg");
        ImageView imageView = (ImageView) findViewById(2131362257);
        qc0 a = mc0.b().a(stringBuilder.toString());
        a.a(2131230965);
        a.a(imageView);
        findViewById(2131362031).setOnClickListener(new b());
        this.v = (RelativeLayout) findViewById(2131362141);
        this.v.setOnClickListener(new c(str2, stringExtra));
        if (Boolean.valueOf(MainActivity.L.b(str2)).booleanValue()) {
            this.x.setLikeDrawable(getResources().getDrawable(2131230921));
            this.x.setLiked(Boolean.valueOf(true));
        }
        this.x.setOnLikeListener(new d(str2, stringExtra, str));
    }

    public final void p() {
        ey b = new ce0(this).b();
        b.a(true);
        b.a(new e());
    }
}
