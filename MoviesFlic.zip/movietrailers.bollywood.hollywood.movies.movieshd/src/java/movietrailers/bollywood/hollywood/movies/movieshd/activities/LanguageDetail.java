package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.by;
import android.support.v7.ce0;
import android.support.v7.cy;
import android.support.v7.ey;
import android.support.v7.i0;
import android.support.v7.jf0;
import android.support.v7.mc0;
import android.support.v7.qc0;
import android.support.v7.qy;
import android.support.v7.ze0;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.d0;
import androidx.recyclerview.widget.RecyclerView.g;
import com.facebook.ads.Ad;
import com.facebook.ads.AdChoicesView;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.Collections;
import movietrailers.bollywood.hollywood.movies.movieshd.classes.ApplicationClass;

public class LanguageDetail extends i0 {
    public TextView A;
    public TextView B;
    public String C;
    public NativeAd D;
    public AdView E;
    public RelativeLayout F;
    public RecyclerView t;
    public ey u;
    public ProgressBar v;
    public ArrayList<jf0> w = new ArrayList();
    public ArrayList<jf0> x = new ArrayList();
    public FloatingActionButton y;
    public ImageView z;

    public class a implements OnClickListener {
        public void onClick(View view) {
            LanguageDetail.this.onBackPressed();
        }
    }

    public class b implements OnClickListener {
        public void onClick(View view) {
            Intent intent = new Intent(LanguageDetail.this, WebSearchingActivity.class);
            intent.putExtra("fragmentName", "1ALL WEB LIST");
            LanguageDetail.this.startActivity(intent);
        }
    }

    public class c implements AdListener {
        public void onAdClicked(Ad ad) {
        }

        public void onAdLoaded(Ad ad) {
            LanguageDetail.this.B.setVisibility(8);
        }

        public void onError(Ad ad, AdError adError) {
            LanguageDetail.this.B.setVisibility(0);
        }

        public void onLoggingImpression(Ad ad) {
        }
    }

    public class d implements qy {
        public void a(by byVar) {
            jf0 jf0;
            for (by byVar2 : byVar.b()) {
                if (byVar2.a("webLang").e().equals(LanguageDetail.this.C)) {
                    jf0 = new jf0();
                    jf0 jf02 = (jf0) byVar2.a(jf0.class);
                    jf0.webThumb = jf02.getWebThumb();
                    jf0.webTitle = jf02.getWebTitle();
                    jf0.webLang = jf02.getWebLang();
                    LanguageDetail.this.w.add(jf0);
                }
            }
            Collections.shuffle(LanguageDetail.this.w);
            int i = 9;
            int i2 = 0;
            while (i2 < LanguageDetail.this.w.size()) {
                if (i2 != 0 && i2 == i) {
                    LanguageDetail.this.x.add(null);
                    i += 8;
                }
                jf0 = (jf0) LanguageDetail.this.w.get(i2);
                jf0 jf03 = new jf0();
                jf03.webThumb = jf0.getWebThumb();
                jf03.webTitle = jf0.getWebTitle();
                jf03.webLang = jf0.getWebLang();
                LanguageDetail.this.x.add(jf03);
                i2++;
            }
            LanguageDetail.this.v.setVisibility(4);
            LanguageDetail languageDetail = LanguageDetail.this;
            e eVar = new e(languageDetail, languageDetail.x);
            LanguageDetail.this.t.setAdapter(eVar);
            eVar.d();
        }

        public void a(cy cyVar) {
        }
    }

    public class e extends g<e> {
        public Context c;
        public ArrayList<jf0> d;
        public int e = 0;
        public int f = 1;

        public class a implements OnClickListener {
            public final /* synthetic */ jf0 c;

            public a(jf0 jf0) {
                this.c = jf0;
            }

            public void onClick(View view) {
                String webTitle = this.c.getWebTitle();
                String webLang = this.c.getWebLang();
                String webThumb = this.c.getWebThumb();
                Intent intent = new Intent(LanguageDetail.this, WebSeriesDetail.class);
                intent.putExtra("webSeriesLang", webLang);
                intent.putExtra("webSeriesName", webTitle);
                intent.putExtra("webSeriesThumb", webThumb);
                LanguageDetail.this.startActivity(intent);
                if (ce0.c(e.this.c) && ze0.q0.isAdLoaded()) {
                    ze0.q0.show();
                    ce0.a(e.this.c, Long.valueOf(System.currentTimeMillis()));
                }
            }
        }

        public class b implements NativeAdListener {
            public final /* synthetic */ c a;

            public b(c cVar) {
                this.a = cVar;
            }

            public void onAdClicked(Ad ad) {
            }

            public void onAdLoaded(Ad ad) {
                if (LanguageDetail.this.D != null && LanguageDetail.this.D == ad) {
                    if (LanguageDetail.this.D != null) {
                        LanguageDetail.this.D.unregisterView();
                    }
                    this.a.x.setText(LanguageDetail.this.D.getAdSocialContext());
                    this.a.z.setText(LanguageDetail.this.D.getAdCallToAction());
                    LanguageDetail languageDetail = LanguageDetail.this;
                    this.a.w.addView(new AdChoicesView(languageDetail, languageDetail.D, true));
                    ArrayList arrayList = new ArrayList();
                    arrayList.add(this.a.w);
                    arrayList.add(this.a.y);
                    arrayList.add(this.a.z);
                    LanguageDetail.this.D.registerViewForInteraction(this.a.v, this.a.y, arrayList);
                }
            }

            public void onError(Ad ad, AdError adError) {
            }

            public void onLoggingImpression(Ad ad) {
            }

            public void onMediaDownloaded(Ad ad) {
            }
        }

        public class e extends d0 {
            public e(e eVar, View view) {
                super(view);
            }
        }

        public class c extends e {
            public LinearLayout v;
            public LinearLayout w;
            public TextView x;
            public MediaView y;
            public Button z;

            public c(e eVar, View view) {
                super(eVar, view);
                this.v = (LinearLayout) view.findViewById(2131362111);
                this.w = (LinearLayout) view.findViewById(2131361858);
                this.x = (TextView) view.findViewById(2131362114);
                this.y = (MediaView) view.findViewById(2131362113);
                this.z = (Button) view.findViewById(2131362110);
            }
        }

        public class d extends e {
            public View v;

            public d(e eVar, View view) {
                super(eVar, view);
                this.v = view;
            }

            public void a(String str) {
                ((TextView) this.v.findViewById(2131362307)).setText(str);
            }

            public void b(String str) {
                ImageView imageView = (ImageView) this.v.findViewById(2131362308);
                qc0 a = mc0.b().a(str);
                a.a(2131230965);
                a.a(imageView);
            }

            public void c(String str) {
                TextView textView = (TextView) this.v.findViewById(2131362309);
                textView.setText(str);
                textView.setSelected(true);
            }
        }

        public e(Context context, ArrayList<jf0> arrayList) {
            this.c = context;
            this.d = arrayList;
        }

        public int a() {
            return this.d.size();
        }

        /* renamed from: a */
        public void b(e eVar, int i) {
            if (eVar.i() == this.e) {
                jf0 jf0 = (jf0) this.d.get(i);
                d dVar = (d) eVar;
                dVar.c(jf0.getWebTitle());
                dVar.b(jf0.getWebThumb());
                dVar.a(jf0.getWebLang());
                dVar.v.setOnClickListener(new a(jf0));
            } else if (eVar.i() == this.f) {
                c cVar = (c) eVar;
                LanguageDetail languageDetail = LanguageDetail.this;
                languageDetail.D = new NativeAd(languageDetail, ((ApplicationClass) languageDetail.getApplication()).q());
                LanguageDetail.this.D.setAdListener(new b(cVar));
                LanguageDetail.this.D.loadAd();
            }
        }

        public int b(int i) {
            return this.d.get(i) == null ? this.f : this.e;
        }

        public e b(ViewGroup viewGroup, int i) {
            return i == this.e ? new d(this, LayoutInflater.from(viewGroup.getContext()).inflate(2131558564, viewGroup, false)) : i == this.f ? new c(this, LayoutInflater.from(viewGroup.getContext()).inflate(2131558440, viewGroup, false)) : null;
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(2131558430);
        this.C = getIntent().getStringExtra("languageType");
        this.F = (RelativeLayout) findViewById(2131361857);
        this.B = (TextView) findViewById(2131361880);
        q();
        this.v = (ProgressBar) findViewById(2131362063);
        this.v.setVisibility(0);
        this.z = (ImageView) findViewById(2131361877);
        this.z.setOnClickListener(new a());
        this.A = (TextView) findViewById(2131362045);
        this.A.setText(this.C);
        this.y = (FloatingActionButton) findViewById(2131362169);
        this.y.setOnClickListener(new b());
        this.t = (RecyclerView) findViewById(2131362022);
        this.t.hasFixedSize();
        this.t.setLayoutManager(new GridLayoutManager(this, 2));
        p();
    }

    public final void p() {
        this.w.clear();
        this.x.clear();
        this.u = new ce0(this).h().b("1ALL WEB LIST");
        this.u.a(true);
        this.u.a(new d());
    }

    public final void q() {
        this.E = new AdView(this, ((ApplicationClass) getApplication()).o(), AdSize.BANNER_HEIGHT_50);
        this.F.removeAllViews();
        this.F.addView(this.E);
        this.E.setAdListener(new c());
        this.E.loadAd();
    }
}
