package movietrailers.bollywood.hollywood.movies.movieshd.flipper;

import android.content.Context;
import android.os.Handler;
import android.support.v7.jg;
import android.support.v7.ke0;
import android.support.v7.ne0;
import android.support.v7.re0;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import androidx.viewpager.widget.ViewPager;
import java.util.Timer;
import java.util.TimerTask;

public class FlipperLayout extends FrameLayout implements android.support.v7.ke0.a {
    public static jg h;
    public int c = 0;
    public ke0 d;
    public ViewPager e;
    public int f = 2;
    public Handler g = new Handler();

    public class a implements Runnable {
        public void run() {
            if (FlipperLayout.this.c == FlipperLayout.getFlippingPagerAdapter().a()) {
                FlipperLayout.this.c = 0;
            }
            ViewPager a = FlipperLayout.this.e;
            FlipperLayout flipperLayout = FlipperLayout.this;
            int i = flipperLayout.c;
            flipperLayout.c = i + 1;
            a.a(i, true);
        }
    }

    public class b extends TimerTask {
        public final /* synthetic */ Runnable c;

        public b(Runnable runnable) {
            this.c = runnable;
        }

        public void run() {
            FlipperLayout.this.g.post(this.c);
        }
    }

    public FlipperLayout(Context context) {
        super(context);
        setLayout(context);
    }

    public FlipperLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setLayout(context);
    }

    public FlipperLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setLayout(context);
    }

    public static jg getFlippingPagerAdapter() {
        return h;
    }

    private void setLayout(Context context) {
        this.e = (ViewPager) LayoutInflater.from(context).inflate(2131558471, this, true).findViewById(2131362296);
        h = new ne0(context);
        this.e.setAdapter(h);
        this.d = new ke0(this.e);
        this.d.a(this);
        this.e.a(this.d);
        a();
    }

    public final void a() {
        new Timer().schedule(new b(new a()), 500, (long) (this.f * 1000));
    }

    public void a(int i) {
        this.c = i;
    }

    public void a(re0 re0) {
        ((ne0) h).a(re0);
    }

    public int getCurrentPagePosition() {
        if (getFlippingPagerAdapter() != null) {
            return this.e.getCurrentItem() % h.a();
        }
        throw new NullPointerException("Adapter not set");
    }

    public int getScrollTimeInSec() {
        return this.f;
    }

    public void setScrollTimeInSec(int i) {
        this.f = i;
        a();
    }
}
