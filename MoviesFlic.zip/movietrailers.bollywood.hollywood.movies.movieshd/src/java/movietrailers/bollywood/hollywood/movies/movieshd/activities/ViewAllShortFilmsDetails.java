package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.by;
import android.support.v7.ce0;
import android.support.v7.cy;
import android.support.v7.ey;
import android.support.v7.gf0;
import android.support.v7.i0;
import android.support.v7.mc0;
import android.support.v7.qc0;
import android.support.v7.qy;
import android.support.v7.xe0;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.d0;
import androidx.recyclerview.widget.RecyclerView.g;
import com.facebook.ads.Ad;
import com.facebook.ads.AdChoicesView;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.Collections;
import movietrailers.bollywood.hollywood.movies.movieshd.classes.ApplicationClass;

public class ViewAllShortFilmsDetails extends i0 {
    public TextView A;
    public TextView B;
    public String C;
    public String D;
    public String E;
    public NativeAd F;
    public AdView G;
    public RelativeLayout H;
    public RecyclerView t;
    public ey u;
    public ProgressBar v;
    public ArrayList<gf0> w = new ArrayList();
    public ArrayList<gf0> x = new ArrayList();
    public FloatingActionButton y;
    public ImageView z;

    public class a implements OnClickListener {
        public void onClick(View view) {
            ViewAllShortFilmsDetails.this.onBackPressed();
        }
    }

    public class b implements OnClickListener {
        public void onClick(View view) {
            Intent intent = new Intent(ViewAllShortFilmsDetails.this, SF_Searching.class);
            intent.putExtra("fragmentName", ViewAllShortFilmsDetails.this.C);
            intent.putExtra("lang", ViewAllShortFilmsDetails.this.E);
            intent.putExtra("toolbarName", ViewAllShortFilmsDetails.this.D);
            ViewAllShortFilmsDetails.this.startActivity(intent);
        }
    }

    public class c implements AdListener {
        public void onAdClicked(Ad ad) {
        }

        public void onAdLoaded(Ad ad) {
            ViewAllShortFilmsDetails.this.B.setVisibility(8);
        }

        public void onError(Ad ad, AdError adError) {
            ViewAllShortFilmsDetails.this.B.setVisibility(0);
        }

        public void onLoggingImpression(Ad ad) {
        }
    }

    public class d implements qy {
        public void a(by byVar) {
            gf0 gf0;
            for (by byVar2 : byVar.b()) {
                gf0 = new gf0();
                gf0 gf02 = (gf0) byVar2.a(gf0.class);
                gf0.title = gf02.getTitle();
                gf0.url = gf02.getUrl();
                ViewAllShortFilmsDetails.this.w.add(gf0);
            }
            Collections.shuffle(ViewAllShortFilmsDetails.this.w);
            int i = 9;
            int i2 = 0;
            while (i2 < ViewAllShortFilmsDetails.this.w.size()) {
                if (i2 != 0 && i2 == i) {
                    ViewAllShortFilmsDetails.this.x.add(null);
                    i += 8;
                }
                gf0 = (gf0) ViewAllShortFilmsDetails.this.w.get(i2);
                gf0 gf03 = new gf0();
                gf03.url = gf0.getUrl();
                gf03.title = gf0.getTitle();
                ViewAllShortFilmsDetails.this.x.add(gf03);
                i2++;
            }
            ViewAllShortFilmsDetails.this.v.setVisibility(4);
            ViewAllShortFilmsDetails viewAllShortFilmsDetails = ViewAllShortFilmsDetails.this;
            e eVar = new e(viewAllShortFilmsDetails, viewAllShortFilmsDetails.x);
            ViewAllShortFilmsDetails.this.t.setAdapter(eVar);
            eVar.d();
        }

        public void a(cy cyVar) {
        }
    }

    public class e extends g<e> {
        public Context c;
        public ArrayList<gf0> d;
        public int e = 0;
        public int f = 1;

        public class a implements OnClickListener {
            public final /* synthetic */ gf0 c;

            public a(gf0 gf0) {
                this.c = gf0;
            }

            public void onClick(View view) {
                String title = this.c.getTitle();
                String url = this.c.getUrl();
                Intent intent = new Intent(ViewAllShortFilmsDetails.this, DetailActivityShort.class);
                intent.putExtra("videoName", title);
                intent.putExtra("videoUrl", url);
                intent.putExtra("language", ViewAllShortFilmsDetails.this.E);
                intent.putExtra("Type", "Short");
                ViewAllShortFilmsDetails.this.startActivity(intent);
                if (ce0.c(e.this.c) && xe0.b1.isAdLoaded()) {
                    xe0.b1.show();
                    ce0.a(e.this.c, Long.valueOf(System.currentTimeMillis()));
                }
            }
        }

        public class b implements NativeAdListener {
            public final /* synthetic */ c a;

            public b(c cVar) {
                this.a = cVar;
            }

            public void onAdClicked(Ad ad) {
            }

            public void onAdLoaded(Ad ad) {
                if (ViewAllShortFilmsDetails.this.F != null && ViewAllShortFilmsDetails.this.F == ad) {
                    if (ViewAllShortFilmsDetails.this.F != null) {
                        ViewAllShortFilmsDetails.this.F.unregisterView();
                    }
                    this.a.x.setText(ViewAllShortFilmsDetails.this.F.getAdSocialContext());
                    this.a.z.setText(ViewAllShortFilmsDetails.this.F.getAdCallToAction());
                    ViewAllShortFilmsDetails viewAllShortFilmsDetails = ViewAllShortFilmsDetails.this;
                    this.a.w.addView(new AdChoicesView(viewAllShortFilmsDetails, viewAllShortFilmsDetails.F, true));
                    ArrayList arrayList = new ArrayList();
                    arrayList.add(this.a.w);
                    arrayList.add(this.a.y);
                    arrayList.add(this.a.z);
                    ViewAllShortFilmsDetails.this.F.registerViewForInteraction(this.a.v, this.a.y, arrayList);
                }
            }

            public void onError(Ad ad, AdError adError) {
            }

            public void onLoggingImpression(Ad ad) {
            }

            public void onMediaDownloaded(Ad ad) {
            }
        }

        public class e extends d0 {
            public e(e eVar, View view) {
                super(view);
            }
        }

        public class c extends e {
            public LinearLayout v;
            public LinearLayout w;
            public TextView x;
            public MediaView y;
            public Button z;

            public c(e eVar, View view) {
                super(eVar, view);
                this.v = (LinearLayout) view.findViewById(2131362111);
                this.w = (LinearLayout) view.findViewById(2131361858);
                this.x = (TextView) view.findViewById(2131362114);
                this.y = (MediaView) view.findViewById(2131362113);
                this.z = (Button) view.findViewById(2131362110);
            }
        }

        public class d extends e {
            public View v;
            public TextView w = ((TextView) this.v.findViewById(2131362309));

            public d(View view) {
                super(e.this, view);
                this.v = view;
            }

            public void C() {
                TextView textView = (TextView) this.v.findViewById(2131362307);
                textView.setText(ViewAllShortFilmsDetails.this.E);
                textView.setSelected(true);
            }

            public void a(String str) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("https://img.youtube.com/vi/");
                stringBuilder.append(str);
                stringBuilder.append("/hqdefault.jpg");
                str = stringBuilder.toString();
                ImageView imageView = (ImageView) this.v.findViewById(2131362308);
                qc0 a = mc0.b().a(str);
                a.a(2131230965);
                a.a(imageView);
            }
        }

        public e(Context context, ArrayList<gf0> arrayList) {
            this.c = context;
            this.d = arrayList;
        }

        public int a() {
            return this.d.size();
        }

        /* renamed from: a */
        public void b(e eVar, int i) {
            if (eVar.i() == this.e) {
                gf0 gf0 = (gf0) this.d.get(i);
                d dVar = (d) eVar;
                dVar.w.setText(gf0.getTitle());
                dVar.w.setSelected(true);
                dVar.a(gf0.getUrl());
                dVar.C();
                dVar.v.setOnClickListener(new a(gf0));
            } else if (eVar.i() == this.f) {
                c cVar = (c) eVar;
                ViewAllShortFilmsDetails viewAllShortFilmsDetails = ViewAllShortFilmsDetails.this;
                viewAllShortFilmsDetails.F = new NativeAd(viewAllShortFilmsDetails, ((ApplicationClass) viewAllShortFilmsDetails.getApplication()).g());
                ViewAllShortFilmsDetails.this.F.setAdListener(new b(cVar));
                ViewAllShortFilmsDetails.this.F.loadAd();
            }
        }

        public int b(int i) {
            return this.d.get(i) == null ? this.f : this.e;
        }

        public e b(ViewGroup viewGroup, int i) {
            return i == this.e ? new d(LayoutInflater.from(viewGroup.getContext()).inflate(2131558564, viewGroup, false)) : i == this.f ? new c(this, LayoutInflater.from(viewGroup.getContext()).inflate(2131558440, viewGroup, false)) : null;
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(2131558430);
        this.C = getIntent().getStringExtra("dbName");
        this.D = getIntent().getStringExtra("toolbarName");
        this.E = getIntent().getStringExtra("lang");
        this.H = (RelativeLayout) findViewById(2131361857);
        this.B = (TextView) findViewById(2131361880);
        q();
        this.v = (ProgressBar) findViewById(2131362063);
        this.v.setVisibility(0);
        this.z = (ImageView) findViewById(2131361877);
        this.z.setOnClickListener(new a());
        this.A = (TextView) findViewById(2131362045);
        this.A.setText(this.D);
        this.y = (FloatingActionButton) findViewById(2131362169);
        this.y.setOnClickListener(new b());
        this.t = (RecyclerView) findViewById(2131362022);
        this.t.hasFixedSize();
        this.t.setLayoutManager(new GridLayoutManager(this, 2));
        p();
    }

    public final void p() {
        this.w.clear();
        this.x.clear();
        this.u = new ce0(this).i().b(this.C);
        this.u.a(true);
        this.u.a(new d());
    }

    public final void q() {
        this.G = new AdView(this, ((ApplicationClass) getApplication()).e(), AdSize.BANNER_HEIGHT_50);
        this.H.removeAllViews();
        this.H.addView(this.G);
        this.G.setAdListener(new c());
        this.G.loadAd();
    }
}
