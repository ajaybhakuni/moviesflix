package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.support.v7.i0;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import movietrailers.bollywood.hollywood.movies.movieshd.classes.ApplicationClass;

public class Gaming extends i0 {
    public RelativeLayout t;
    public AdView u;
    public ProgressBar v;
    public TextView w;
    public WebView x;

    public class a extends WebViewClient {

        public class a implements OnClickListener {
            public a(a aVar) {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
            }
        }

        public void onPageFinished(WebView webView, String str) {
            Gaming.this.v.setVisibility(8);
        }

        public void onReceivedError(WebView webView, int i, String str, String str2) {
            Gaming gaming = Gaming.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Something Went Wrong! ");
            stringBuilder.append(str);
            Toast.makeText(gaming, stringBuilder.toString(), 0).show();
            android.support.v7.h0.a aVar = new android.support.v7.h0.a(Gaming.this);
            aVar.b("Error");
            aVar.a(str);
            aVar.a("OK", new a(this));
            aVar.c();
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            webView.loadUrl(str);
            return true;
        }
    }

    public class b implements AdListener {
        public void onAdClicked(Ad ad) {
        }

        public void onAdLoaded(Ad ad) {
            Gaming.this.w.setVisibility(8);
        }

        public void onError(Ad ad, AdError adError) {
            Gaming.this.w.setVisibility(0);
        }

        public void onLoggingImpression(Ad ad) {
        }
    }

    public class c implements OnClickListener {
        public void onClick(DialogInterface dialogInterface, int i) {
            Gaming.this.finish();
        }
    }

    public void onBackPressed() {
        if (!this.x.canGoBack() || this.x.copyBackForwardList().getSize() <= 0 || this.x.getUrl().equals(this.x.copyBackForwardList().getItemAtIndex(0).getOriginalUrl())) {
            android.support.v7.h0.a aVar = new android.support.v7.h0.a(this);
            aVar.a(getString(2131820654));
            aVar.a(false);
            aVar.a(2131820715, null);
            aVar.b(2131820777, new c());
            aVar.a().show();
            return;
        }
        this.x.goBack();
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131558429);
        this.v = (ProgressBar) findViewById(2131362142);
        this.v.setVisibility(0);
        this.t = (RelativeLayout) findViewById(2131361857);
        this.w = (TextView) findViewById(2131361880);
        p();
        this.x = (WebView) findViewById(2131362300);
        this.x.getSettings().setJavaScriptEnabled(true);
        this.x.setWebViewClient(new a());
        this.x.loadUrl(((ApplicationClass) getApplication()).b());
    }

    public final void p() {
        this.u = new AdView(this, ((ApplicationClass) getApplication()).l(), AdSize.BANNER_HEIGHT_50);
        this.t.removeAllViews();
        this.t.addView(this.u);
        this.u.setAdListener(new b());
        this.u.loadAd();
    }
}
