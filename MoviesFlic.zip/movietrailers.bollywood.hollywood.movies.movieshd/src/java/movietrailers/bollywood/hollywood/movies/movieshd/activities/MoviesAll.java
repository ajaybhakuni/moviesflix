package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.ef0;
import android.support.v7.i0;
import android.support.v7.vd0;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.SearchView.m;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.d0;
import androidx.recyclerview.widget.RecyclerView.g;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import movietrailers.bollywood.hollywood.movies.movieshd.classes.ApplicationClass;

public class MoviesAll extends i0 {
    public AdView A;
    public RelativeLayout B;
    public LayoutParams C;
    public Dialog D;
    public RecyclerView t;
    public ProgressBar u;
    public ArrayList<ef0> v = new ArrayList();
    public final ArrayList<ef0> w = new ArrayList();
    public ImageView x;
    public TextView y;
    public FloatingActionButton z;

    public class a implements OnClickListener {
        public void onClick(View view) {
            MoviesAll.this.onBackPressed();
        }
    }

    public class b implements OnClickListener {

        public class a implements m {
            public final /* synthetic */ RecyclerView a;

            public a(RecyclerView recyclerView) {
                this.a = recyclerView;
            }

            public boolean a(String str) {
                if (str == null || str.trim().isEmpty()) {
                    RecyclerView recyclerView = this.a;
                    MoviesAll moviesAll = MoviesAll.this;
                    recyclerView.setAdapter(new d(moviesAll.v));
                    return false;
                }
                ArrayList arrayList = new ArrayList();
                Iterator it = ((ArrayList) MoviesAll.this.getIntent().getSerializableExtra("inner_arraylist")).iterator();
                while (it.hasNext()) {
                    ef0 ef0 = (ef0) it.next();
                    if (ef0.getTitle().toLowerCase().contains(str.toLowerCase())) {
                        arrayList.add(ef0);
                    }
                }
                this.a.setAdapter(new d(arrayList));
                return false;
            }

            public boolean b(String str) {
                return false;
            }
        }

        public void onClick(View view) {
            MoviesAll moviesAll = MoviesAll.this;
            moviesAll.D = new Dialog(moviesAll);
            MoviesAll.this.D.setContentView(2131558546);
            MoviesAll.this.D.setCanceledOnTouchOutside(false);
            SearchView searchView = (SearchView) MoviesAll.this.D.findViewById(2131362176);
            searchView.setIconifiedByDefault(false);
            searchView.setFocusable(true);
            searchView.setIconified(false);
            searchView.requestFocusFromTouch();
            EditText editText = (EditText) searchView.findViewById(2131362186);
            editText.setHint("Search Movies");
            editText.setHintTextColor(-3355444);
            editText.setTextColor(-3355444);
            RecyclerView recyclerView = (RecyclerView) MoviesAll.this.D.findViewById(2131362185);
            recyclerView.hasFixedSize();
            recyclerView.setLayoutManager(new LinearLayoutManager(MoviesAll.this, 1, false));
            searchView.setOnQueryTextListener(new a(recyclerView));
            MoviesAll.this.D.show();
        }
    }

    public class c implements AdListener {
        public void onAdClicked(Ad ad) {
        }

        public void onAdLoaded(Ad ad) {
        }

        public void onError(Ad ad, AdError adError) {
            MoviesAll.this.B.setVisibility(8);
        }

        public void onLoggingImpression(Ad ad) {
        }
    }

    public class d extends g<b> {
        public ArrayList<ef0> c;

        public class a implements OnClickListener {
            public final /* synthetic */ ef0 c;

            public a(ef0 ef0) {
                this.c = ef0;
            }

            public void onClick(View view) {
                Intent intent = new Intent(MoviesAll.this, DetailActivityShort.class);
                intent.putExtra("videoName", this.c.getTitle());
                intent.putExtra("videoThumb", this.c.getThumb());
                intent.putExtra("videoUrl", this.c.getVideoId());
                intent.putExtra("videoDescp", this.c.getDescp());
                intent.putExtra("Type", "Movies");
                MoviesAll.this.startActivity(intent);
            }
        }

        public class b extends d0 {
            public TextView v;
            public View w;

            public b(d dVar, View view) {
                super(view);
                this.w = view;
                this.v = (TextView) view.findViewById(2131362175);
            }

            public /* synthetic */ b(d dVar, View view, a aVar) {
                this(dVar, view);
            }
        }

        public d(ArrayList<ef0> arrayList) {
            this.c = arrayList;
        }

        public int a() {
            return this.c.size();
        }

        /* renamed from: a */
        public void b(b bVar, int i) {
            ef0 ef0 = (ef0) this.c.get(i);
            bVar.v.setText(ef0.getTitle());
            bVar.w.setOnClickListener(new a(ef0));
        }

        public b b(ViewGroup viewGroup, int i) {
            return new b(this, LayoutInflater.from(MoviesAll.this).inflate(2131558542, viewGroup, false), null);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131558433);
        this.u = (ProgressBar) findViewById(2131362063);
        this.u.setVisibility(0);
        this.x = (ImageView) findViewById(2131361877);
        this.x.setOnClickListener(new a());
        String stringExtra = getIntent().getStringExtra("cat_title");
        this.y = (TextView) findViewById(2131362045);
        this.y.setText(stringExtra);
        this.B = (RelativeLayout) findViewById(2131361857);
        this.C = new LayoutParams(-2, -2);
        this.C.addRule(14);
        q();
        this.z = (FloatingActionButton) findViewById(2131362169);
        this.t = (RecyclerView) findViewById(2131362022);
        this.t.hasFixedSize();
        this.t.setLayoutManager(new GridLayoutManager(this, 2));
        p();
        this.z.setOnClickListener(new b());
    }

    public final void p() {
        ArrayList arrayList = (ArrayList) getIntent().getSerializableExtra("inner_arraylist");
        Collections.shuffle(arrayList);
        int i = 5;
        int i2 = 0;
        while (i2 < arrayList.size()) {
            if (i2 != 0 && i2 == i) {
                this.w.add(null);
                i += 8;
            }
            ef0 ef0 = (ef0) arrayList.get(i2);
            ef0 ef02 = new ef0();
            ef02.title = ef0.getTitle();
            ef02.thumb = ef0.getThumb();
            ef02.videoId = ef0.getVideoId();
            ef02.descp = ef0.getDescp();
            this.w.add(ef0);
            i2++;
        }
        this.u.setVisibility(8);
        this.t.setAdapter(new vd0(this, this.w));
    }

    public final void q() {
        this.A = new AdView(this, ((ApplicationClass) getApplication()).i(), AdSize.BANNER_HEIGHT_50);
        this.B.removeAllViews();
        this.B.addView(this.A, this.C);
        this.A.setAdListener(new c());
        this.A.loadAd();
    }
}
