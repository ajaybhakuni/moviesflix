package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.os.Bundle;
import android.support.v7.by;
import android.support.v7.ce0;
import android.support.v7.cy;
import android.support.v7.fe0;
import android.support.v7.i0;
import android.support.v7.qy;
import android.support.v7.td;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class SearchingActivity extends i0 {
    public fe0 A;
    public String B;
    public EditText t;
    public RecyclerView u;
    public ImageView v;
    public ArrayList<String> w;
    public ArrayList<String> x;
    public ArrayList<String> y;
    public ArrayList<String> z;

    public class a implements OnClickListener {
        public void onClick(View view) {
            SearchingActivity.this.onBackPressed();
            SearchingActivity.this.finish();
        }
    }

    public class b implements TextWatcher {
        public void afterTextChanged(Editable editable) {
            if (editable.toString().isEmpty()) {
                SearchingActivity.this.x.clear();
                SearchingActivity.this.y.clear();
                SearchingActivity.this.w.clear();
                SearchingActivity.this.z.clear();
                SearchingActivity.this.u.removeAllViews();
                return;
            }
            SearchingActivity.this.a(editable.toString());
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }
    }

    public class c implements qy {
        public final /* synthetic */ String a;

        public c(String str) {
            this.a = str;
        }

        public void a(by byVar) {
            SearchingActivity.this.x.clear();
            SearchingActivity.this.y.clear();
            SearchingActivity.this.w.clear();
            SearchingActivity.this.z.clear();
            SearchingActivity.this.u.removeAllViews();
            int i = 0;
            for (by byVar2 : byVar.b()) {
                String str = (String) byVar2.a("title").a(String.class);
                String str2 = (String) byVar2.a("lang").a(String.class);
                String str3 = "url";
                String str4 = (String) byVar2.a(str3).a(String.class);
                String str5 = (String) byVar2.a(str3).a(String.class);
                if (str != null && str.toLowerCase().contains(this.a.toLowerCase())) {
                    SearchingActivity.this.x.add(str2);
                    SearchingActivity.this.y.add(str5);
                    SearchingActivity.this.w.add(str);
                    SearchingActivity.this.z.add(str4);
                    i++;
                }
                if (i == 15) {
                    break;
                }
            }
            SearchingActivity searchingActivity = SearchingActivity.this;
            searchingActivity.A = new fe0(searchingActivity, searchingActivity.y, searchingActivity.x, searchingActivity.w, searchingActivity.z);
            searchingActivity = SearchingActivity.this;
            searchingActivity.u.setAdapter(searchingActivity.A);
        }

        public void a(cy cyVar) {
        }
    }

    public final void a(String str) {
        new ce0(this).g().b(getIntent().getStringExtra("fragmentName")).a(new c(str));
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(2131558435);
        this.v = (ImageView) findViewById(2131361879);
        this.v.setOnClickListener(new a());
        this.t = (EditText) findViewById(2131362174);
        this.t.setFocusable(true);
        this.t.requestFocusFromTouch();
        p();
        this.u = (RecyclerView) findViewById(2131362173);
        this.u.setHasFixedSize(true);
        this.u.setLayoutManager(new LinearLayoutManager(this));
        this.u.addItemDecoration(new td(this, 1));
        this.x = new ArrayList();
        this.y = new ArrayList();
        this.w = new ArrayList();
        this.z = new ArrayList();
        this.t.addTextChangedListener(new b());
    }

    public final void p() {
        EditText editText;
        int i;
        this.B = getIntent().getStringExtra("fragmentName");
        if (this.B.equals("Hollywood_M")) {
            editText = this.t;
            i = 2131820742;
        } else if (this.B.equals("Bollywood_M")) {
            editText = this.t;
            i = 2131820736;
        } else if (this.B.equals("South_M")) {
            editText = this.t;
            i = 2131820750;
        } else if (this.B.equals("Punjabi_M")) {
            editText = this.t;
            i = 2131820748;
        } else if (this.B.equals("Marathi_M")) {
            editText = this.t;
            i = 2131820746;
        } else if (this.B.equals("Guj_M")) {
            editText = this.t;
            i = 2131820740;
        } else if (this.B.equals("Chinese_M")) {
            editText = this.t;
            i = 2131820738;
        } else if (this.B.equals("Korean_M")) {
            editText = this.t;
            i = 2131820744;
        } else if (this.B.equals("Hollywood_T")) {
            editText = this.t;
            i = 2131820743;
        } else if (this.B.equals("Bollywood_T")) {
            editText = this.t;
            i = 2131820737;
        } else if (this.B.equals("South_T")) {
            editText = this.t;
            i = 2131820751;
        } else if (this.B.equals("Punjabi_T")) {
            editText = this.t;
            i = 2131820749;
        } else if (this.B.equals("Marathi_T")) {
            editText = this.t;
            i = 2131820747;
        } else if (this.B.equals("Guj_T")) {
            editText = this.t;
            i = 2131820741;
        } else if (this.B.equals("Chinese_T")) {
            editText = this.t;
            i = 2131820739;
        } else if (this.B.equals("Korean_T")) {
            editText = this.t;
            i = 2131820745;
        } else {
            return;
        }
        editText.setHint(i);
    }
}
