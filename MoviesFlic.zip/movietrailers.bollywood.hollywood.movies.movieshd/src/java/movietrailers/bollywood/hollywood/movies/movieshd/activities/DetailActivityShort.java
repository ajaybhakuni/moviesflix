package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.af0;
import android.support.v7.ay;
import android.support.v7.by;
import android.support.v7.ce0;
import android.support.v7.cy;
import android.support.v7.ey;
import android.support.v7.i0;
import android.support.v7.mc0;
import android.support.v7.nb0;
import android.support.v7.qc0;
import android.support.v7.se0;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.cardview.widget.CardView;
import com.like.LikeButton;
import movietrailers.bollywood.hollywood.movies.movieshd.flipper.FlipperLayoutAd;

public class DetailActivityShort extends i0 {
    public String A;
    public String B;
    public String C;
    public String D;
    public String E;
    public CardView F;
    public LinearLayout G;
    public FlipperLayoutAd H;
    public TextView t;
    public TextView u;
    public TextView v;
    public RelativeLayout w;
    public ImageView x;
    public LikeButton y;
    public String z;

    public class a implements OnClickListener {
        public void onClick(View view) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("https://www.youtube.com/watch?v=");
            stringBuilder.append(DetailActivityShort.this.A);
            String stringBuilder2 = stringBuilder.toString();
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(stringBuilder2));
            DetailActivityShort.this.startActivity(intent);
        }
    }

    public class b implements OnClickListener {
        public void onClick(View view) {
            DetailActivityShort.this.onBackPressed();
        }
    }

    public class c implements OnClickListener {
        public void onClick(View view) {
            String str = "android.intent.action.VIEW";
            Intent intent = new Intent(str, Uri.parse("http://instagram.com/_u/movieflix_entertainment"));
            intent.setPackage("com.instagram.android");
            try {
                DetailActivityShort.this.startActivity(intent);
            } catch (ActivityNotFoundException unused) {
                DetailActivityShort.this.startActivity(new Intent(str, Uri.parse("http://instagram.com/movieflix_entertainment")));
            }
        }
    }

    public class d implements OnClickListener {
        public void onClick(View view) {
            String str;
            String d;
            Intent intent = new Intent(DetailActivityShort.this, PlayerActivityShort.class);
            intent.putExtra("videoUrl", DetailActivityShort.this.A);
            intent.putExtra("videoName", DetailActivityShort.this.z);
            if (DetailActivityShort.this.C.equals("Movies")) {
                str = "videoThumb";
                intent.putExtra(str, DetailActivityShort.this.getIntent().getStringExtra(str));
                d = DetailActivityShort.this.D;
                str = "videoDescp";
            } else {
                d = DetailActivityShort.this.B;
                str = "language";
            }
            intent.putExtra(str, d);
            intent.putExtra("Type", DetailActivityShort.this.C);
            DetailActivityShort.this.startActivity(intent);
            DetailActivityShort.this.finish();
        }
    }

    public class e implements nb0 {
        public void a(LikeButton likeButton) {
            DetailActivityShort detailActivityShort = DetailActivityShort.this;
            if (detailActivityShort.a(detailActivityShort.A)) {
                DetailActivityShort.this.y.setLikeDrawable(DetailActivityShort.this.getResources().getDrawable(2131230922));
            }
            DetailActivityShort.this.y.setLiked(Boolean.valueOf(false));
            if (MainActivity.L.f(DetailActivityShort.this.A).intValue() > 0) {
                Toast.makeText(DetailActivityShort.this, "Removed from Favourite", 0).show();
            }
        }

        public void b(LikeButton likeButton) {
            DetailActivityShort detailActivityShort = DetailActivityShort.this;
            if (!detailActivityShort.a(detailActivityShort.A)) {
                DetailActivityShort.this.y.setLikeDrawable(DetailActivityShort.this.getResources().getDrawable(2131230921));
                DetailActivityShort.this.y.setLiked(Boolean.valueOf(true));
                try {
                    (DetailActivityShort.this.C.equals("Movies") ? MainActivity.L.a(DetailActivityShort.this.A, DetailActivityShort.this.z, "", "", "", DetailActivityShort.this.C, DetailActivityShort.this.getIntent().getStringExtra("videoThumb"), DetailActivityShort.this.D) : MainActivity.L.a(DetailActivityShort.this.A, DetailActivityShort.this.z, DetailActivityShort.this.B, "", "", DetailActivityShort.this.C, "", "") ? Toast.makeText(DetailActivityShort.this, "Added to Favourite", 0) : Toast.makeText(DetailActivityShort.this, "Not Added to Favourite", 0)).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public class f implements ay {

        public class a implements android.support.v7.se0.b {
            public final /* synthetic */ af0 a;

            public a(af0 af0) {
                this.a = af0;
            }

            public void a(se0 se0) {
                try {
                    DetailActivityShort detailActivityShort = DetailActivityShort.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("market://details?id=");
                    stringBuilder.append(this.a.getFlipAdUrl());
                    detailActivityShort.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(stringBuilder.toString())));
                } catch (ActivityNotFoundException unused) {
                }
            }
        }

        public void a(by byVar) {
        }

        public void a(by byVar, String str) {
        }

        public void a(cy cyVar) {
        }

        public void b(by byVar, String str) {
        }

        public void c(by byVar, String str) {
            af0 af0 = (af0) byVar.a(af0.class);
            se0 se0 = new se0(DetailActivityShort.this);
            se0.c(String.valueOf(af0.getFlipAdThumb()));
            se0.a(ScaleType.FIT_XY);
            se0.a(af0.getFlipAdDescp());
            se0.b(af0.getFlipAdName());
            se0.d(af0.getS1());
            se0.e(af0.getS2());
            se0.f(af0.getS3());
            se0.g(af0.getS4());
            DetailActivityShort.this.H.a(se0);
            se0.a(new a(af0));
        }
    }

    public final boolean a(String str) {
        return Boolean.valueOf(MainActivity.L.b(str)).booleanValue();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(2131558428);
        this.G = (LinearLayout) findViewById(2131361949);
        this.v = (TextView) findViewById(2131362085);
        this.H = (FlipperLayoutAd) findViewById(2131361988);
        p();
        this.C = getIntent().getStringExtra("Type");
        String str = "Movies";
        if (!this.C.equals(str)) {
            this.B = getIntent().getStringExtra("language");
        }
        this.z = getIntent().getStringExtra("videoName");
        this.A = getIntent().getStringExtra("videoUrl");
        this.F = (CardView) findViewById(2131362295);
        if (this.C.equals("Short")) {
            this.F.setVisibility(0);
        }
        this.F.setOnClickListener(new a());
        this.t = (TextView) findViewById(2131362291);
        this.u = (TextView) findViewById(2131362268);
        this.t.setText(this.z);
        this.t.setSelected(true);
        this.u.setText(this.z);
        this.y = (LikeButton) findViewById(2131361978);
        this.x = (ImageView) findViewById(2131361876);
        this.x.setOnClickListener(new b());
        if (this.C.equals(str)) {
            this.E = getIntent().getStringExtra("videoThumb");
            this.G.setVisibility(0);
            this.D = getIntent().getStringExtra("videoDescp");
            this.v.setText(this.D);
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("https://img.youtube.com/vi/");
            stringBuilder.append(this.A);
            stringBuilder.append("/hqdefault.jpg");
            this.E = stringBuilder.toString();
        }
        ImageView imageView = (ImageView) findViewById(2131362257);
        qc0 a = mc0.b().a(this.E);
        a.a(2131230965);
        a.a(imageView);
        findViewById(2131362031).setOnClickListener(new c());
        this.w = (RelativeLayout) findViewById(2131362141);
        this.w.setOnClickListener(new d());
        if (Boolean.valueOf(MainActivity.L.b(this.A)).booleanValue()) {
            this.y.setLikeDrawable(getResources().getDrawable(2131230921));
            this.y.setLiked(Boolean.valueOf(true));
        }
        this.y.setOnLikeListener(new e());
    }

    public final void p() {
        ey b = new ce0(this).b();
        b.a(true);
        b.a(new f());
    }
}
