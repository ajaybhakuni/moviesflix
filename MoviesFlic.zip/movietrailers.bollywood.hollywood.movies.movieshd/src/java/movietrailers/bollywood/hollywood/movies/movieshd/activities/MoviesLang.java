package movietrailers.bollywood.hollywood.movies.movieshd.activities;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.by;
import android.support.v7.ce0;
import android.support.v7.cy;
import android.support.v7.ef0;
import android.support.v7.ey;
import android.support.v7.i0;
import android.support.v7.qy;
import android.support.v7.vd0;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.SearchView.m;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.d0;
import androidx.recyclerview.widget.RecyclerView.g;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import movietrailers.bollywood.hollywood.movies.movieshd.classes.ApplicationClass;

public class MoviesLang extends i0 {
    public TextView A;
    public TextView B;
    public FloatingActionButton C;
    public AdView D;
    public String E;
    public RelativeLayout F;
    public Dialog G;
    public RecyclerView t;
    public ProgressBar u;
    public final ArrayList<ef0> v = new ArrayList();
    public final ArrayList<ef0> w = new ArrayList();
    public ArrayList<ef0> x = new ArrayList();
    public ey y;
    public ImageView z;

    public class a implements OnClickListener {
        public void onClick(View view) {
            MoviesLang.this.onBackPressed();
        }
    }

    public class b implements OnClickListener {

        public class a implements m {
            public final /* synthetic */ RecyclerView a;

            public a(RecyclerView recyclerView) {
                this.a = recyclerView;
            }

            public boolean a(String str) {
                if (str == null || str.trim().isEmpty()) {
                    RecyclerView recyclerView = this.a;
                    MoviesLang moviesLang = MoviesLang.this;
                    recyclerView.setAdapter(new e(moviesLang.x));
                    return false;
                }
                ArrayList arrayList = new ArrayList();
                Iterator it = MoviesLang.this.v.iterator();
                while (it.hasNext()) {
                    ef0 ef0 = (ef0) it.next();
                    if (ef0.getTitle().toLowerCase().contains(str.toLowerCase())) {
                        arrayList.add(ef0);
                    }
                }
                this.a.setAdapter(new e(arrayList));
                return false;
            }

            public boolean b(String str) {
                return false;
            }
        }

        public void onClick(View view) {
            MoviesLang moviesLang = MoviesLang.this;
            moviesLang.G = new Dialog(moviesLang);
            MoviesLang.this.G.setContentView(2131558546);
            MoviesLang.this.G.setCanceledOnTouchOutside(false);
            SearchView searchView = (SearchView) MoviesLang.this.G.findViewById(2131362176);
            searchView.setIconifiedByDefault(false);
            searchView.setFocusable(true);
            searchView.setIconified(false);
            searchView.requestFocusFromTouch();
            EditText editText = (EditText) searchView.findViewById(2131362186);
            editText.setHint("Search Movies");
            editText.setHintTextColor(-3355444);
            editText.setTextColor(-3355444);
            RecyclerView recyclerView = (RecyclerView) MoviesLang.this.G.findViewById(2131362185);
            recyclerView.hasFixedSize();
            recyclerView.setLayoutManager(new LinearLayoutManager(MoviesLang.this, 1, false));
            searchView.setOnQueryTextListener(new a(recyclerView));
            MoviesLang.this.G.show();
        }
    }

    public class c implements AdListener {
        public void onAdClicked(Ad ad) {
        }

        public void onAdLoaded(Ad ad) {
            MoviesLang.this.B.setVisibility(8);
        }

        public void onError(Ad ad, AdError adError) {
            MoviesLang.this.B.setVisibility(0);
        }

        public void onLoggingImpression(Ad ad) {
        }
    }

    public class d implements qy {
        public void a(by byVar) {
            ef0 ef0;
            for (by a : byVar.b()) {
                ef0 ef02 = (ef0) a.a(ef0.class);
                ef0 = new ef0();
                ef0.title = ef02.getTitle();
                ef0.thumb = ef02.getThumb();
                ef0.videoId = ef02.getVideoId();
                ef0.descp = ef02.getDescp();
                MoviesLang.this.v.add(ef0);
            }
            Collections.shuffle(MoviesLang.this.v);
            int i = 5;
            int i2 = 0;
            while (i2 < MoviesLang.this.v.size()) {
                if (i2 != 0 && i2 == i) {
                    MoviesLang.this.w.add(null);
                    i += 8;
                }
                ef0 = (ef0) MoviesLang.this.v.get(i2);
                ef0 ef03 = new ef0();
                ef03.title = ef0.getTitle();
                ef03.thumb = ef0.getThumb();
                ef03.videoId = ef0.getVideoId();
                ef03.descp = ef0.getDescp();
                MoviesLang.this.w.add(ef0);
                i2++;
            }
            MoviesLang.this.u.setVisibility(8);
            MoviesLang moviesLang = MoviesLang.this;
            MoviesLang.this.t.setAdapter(new vd0(moviesLang, moviesLang.w));
        }

        public void a(cy cyVar) {
        }
    }

    public class e extends g<b> {
        public ArrayList<ef0> c;

        public class a implements OnClickListener {
            public final /* synthetic */ ef0 c;

            public a(ef0 ef0) {
                this.c = ef0;
            }

            public void onClick(View view) {
                Intent intent = new Intent(MoviesLang.this, DetailActivityShort.class);
                intent.putExtra("videoName", this.c.getTitle());
                intent.putExtra("videoThumb", this.c.getThumb());
                intent.putExtra("videoUrl", this.c.getVideoId());
                intent.putExtra("videoDescp", this.c.getDescp());
                intent.putExtra("Type", "Movies");
                MoviesLang.this.startActivity(intent);
            }
        }

        public class b extends d0 {
            public TextView v;
            public View w;

            public b(e eVar, View view) {
                super(view);
                this.w = view;
                this.v = (TextView) view.findViewById(2131362175);
            }

            public /* synthetic */ b(e eVar, View view, a aVar) {
                this(eVar, view);
            }
        }

        public e(ArrayList<ef0> arrayList) {
            this.c = arrayList;
        }

        public int a() {
            return this.c.size();
        }

        /* renamed from: a */
        public void b(b bVar, int i) {
            ef0 ef0 = (ef0) this.c.get(i);
            bVar.v.setText(ef0.getTitle());
            bVar.w.setOnClickListener(new a(ef0));
        }

        public b b(ViewGroup viewGroup, int i) {
            return new b(this, LayoutInflater.from(MoviesLang.this).inflate(2131558542, viewGroup, false), null);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131558433);
        this.u = (ProgressBar) findViewById(2131362063);
        this.u.setVisibility(0);
        this.B = (TextView) findViewById(2131361880);
        this.z = (ImageView) findViewById(2131361877);
        this.z.setOnClickListener(new a());
        this.E = getIntent().getStringExtra("cat_title");
        this.A = (TextView) findViewById(2131362045);
        this.A.setText(this.E);
        this.C = (FloatingActionButton) findViewById(2131362169);
        this.y = new ce0(this).a(this.E);
        this.y.a(true);
        this.F = (RelativeLayout) findViewById(2131361857);
        q();
        this.C = (FloatingActionButton) findViewById(2131362169);
        this.t = (RecyclerView) findViewById(2131362022);
        this.t.hasFixedSize();
        this.t.setLayoutManager(new GridLayoutManager(this, 2));
        p();
        this.C.setOnClickListener(new b());
    }

    public final void p() {
        this.v.clear();
        this.w.clear();
        this.y.a(new d());
    }

    public final void q() {
        this.D = new AdView(this, ((ApplicationClass) getApplication()).i(), AdSize.BANNER_HEIGHT_50);
        this.F.removeAllViews();
        this.F.addView(this.D);
        this.D.setAdListener(new c());
        this.D.loadAd();
    }
}
