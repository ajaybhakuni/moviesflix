package com.like;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.v7.k7;
import android.support.v7.kb0;
import android.support.v7.lb0;
import android.support.v7.mb0;
import android.support.v7.nb0;
import android.support.v7.ob0;
import android.support.v7.qb0;
import android.support.v7.rb0;
import android.support.v7.sb0;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

public class LikeButton extends FrameLayout implements OnClickListener {
    public static final DecelerateInterpolator t = new DecelerateInterpolator();
    public static final AccelerateDecelerateInterpolator u = new AccelerateDecelerateInterpolator();
    public static final OvershootInterpolator v = new OvershootInterpolator(4.0f);
    public ImageView c;
    public DotsView d;
    public CircleView e;
    public kb0 f;
    public nb0 g;
    public mb0 h;
    public int i;
    public int j;
    public int k;
    public int l;
    public int m;
    public float n;
    public boolean o;
    public boolean p;
    public AnimatorSet q;
    public Drawable r;
    public Drawable s;

    public class a extends AnimatorListenerAdapter {
        public void onAnimationCancel(Animator animator) {
            LikeButton.this.e.setInnerCircleRadiusProgress(0.0f);
            LikeButton.this.e.setOuterCircleRadiusProgress(0.0f);
            LikeButton.this.d.setCurrentProgress(0.0f);
            LikeButton.this.c.setScaleX(1.0f);
            LikeButton.this.c.setScaleY(1.0f);
        }

        public void onAnimationEnd(Animator animator) {
            if (LikeButton.this.h != null) {
                LikeButton.this.h.a(LikeButton.this);
            }
        }
    }

    public LikeButton(Context context) {
        this(context, null);
    }

    public LikeButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public LikeButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        if (!isInEditMode()) {
            a(context, attributeSet, i);
        }
    }

    public final Drawable a(TypedArray typedArray, int i) {
        int resourceId = typedArray.getResourceId(i, -1);
        return -1 != resourceId ? k7.c(getContext(), resourceId) : null;
    }

    public final kb0 a(lb0 lb0) {
        for (kb0 kb0 : ob0.a()) {
            if (kb0.a().equals(lb0)) {
                return kb0;
            }
        }
        throw new IllegalArgumentException("Correct icon type not specified.");
    }

    public final kb0 a(String str) {
        for (kb0 kb0 : ob0.a()) {
            if (kb0.a().name().toLowerCase().equals(str.toLowerCase())) {
                return kb0;
            }
        }
        throw new IllegalArgumentException("Correct icon type not specified.");
    }

    public final void a() {
        int i = this.m;
        if (i != 0) {
            DotsView dotsView = this.d;
            float f = (float) i;
            float f2 = this.n;
            dotsView.b((int) (f * f2), (int) (((float) i) * f2));
            CircleView circleView = this.e;
            int i2 = this.m;
            circleView.a(i2, i2);
        }
    }

    public final void a(Context context, AttributeSet attributeSet, int i) {
        LayoutInflater.from(getContext()).inflate(rb0.likeview, this, true);
        this.c = (ImageView) findViewById(qb0.icon);
        this.d = (DotsView) findViewById(qb0.dots);
        this.e = (CircleView) findViewById(qb0.circle);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, sb0.LikeButton, i, 0);
        this.m = obtainStyledAttributes.getDimensionPixelSize(sb0.LikeButton_icon_size, -1);
        if (this.m == -1) {
            this.m = 40;
        }
        String string = obtainStyledAttributes.getString(sb0.LikeButton_icon_type);
        this.r = a(obtainStyledAttributes, sb0.LikeButton_like_drawable);
        Drawable drawable = this.r;
        if (drawable != null) {
            setLikeDrawable(drawable);
        }
        this.s = a(obtainStyledAttributes, sb0.LikeButton_unlike_drawable);
        drawable = this.s;
        if (drawable != null) {
            setUnlikeDrawable(drawable);
        }
        if (!(string == null || string.isEmpty())) {
            this.f = a(string);
        }
        this.k = obtainStyledAttributes.getColor(sb0.LikeButton_circle_start_color, 0);
        int i2 = this.k;
        if (i2 != 0) {
            this.e.setStartColor(i2);
        }
        this.l = obtainStyledAttributes.getColor(sb0.LikeButton_circle_end_color, 0);
        i2 = this.l;
        if (i2 != 0) {
            this.e.setEndColor(i2);
        }
        this.i = obtainStyledAttributes.getColor(sb0.LikeButton_dots_primary_color, 0);
        this.j = obtainStyledAttributes.getColor(sb0.LikeButton_dots_secondary_color, 0);
        i2 = this.i;
        if (i2 != 0) {
            i = this.j;
            if (i != 0) {
                this.d.a(i2, i);
            }
        }
        if (this.r == null && this.s == null) {
            if (this.f != null) {
                b();
            } else {
                setIcon(lb0.c);
            }
        }
        setEnabled(obtainStyledAttributes.getBoolean(sb0.LikeButton_is_enabled, true));
        Boolean valueOf = Boolean.valueOf(obtainStyledAttributes.getBoolean(sb0.LikeButton_liked, false));
        setAnimationScaleFactor(obtainStyledAttributes.getFloat(sb0.LikeButton_anim_scale_factor, 3.0f));
        setLiked(valueOf);
        setOnClickListener(this);
        obtainStyledAttributes.recycle();
    }

    public void b() {
        setLikeDrawableRes(this.f.c());
        setUnlikeDrawableRes(this.f.b());
        this.c.setImageDrawable(this.s);
    }

    public void onClick(View view) {
        if (this.p) {
            this.o ^= 1;
            this.c.setImageDrawable(this.o ? this.r : this.s);
            nb0 nb0 = this.g;
            if (nb0 != null) {
                if (this.o) {
                    nb0.b(this);
                } else {
                    nb0.a(this);
                }
            }
            AnimatorSet animatorSet = this.q;
            if (animatorSet != null) {
                animatorSet.cancel();
            }
            if (this.o) {
                this.c.animate().cancel();
                this.c.setScaleX(0.0f);
                this.c.setScaleY(0.0f);
                this.e.setInnerCircleRadiusProgress(0.0f);
                this.e.setOuterCircleRadiusProgress(0.0f);
                this.d.setCurrentProgress(0.0f);
                this.q = new AnimatorSet();
                ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this.e, CircleView.p, new float[]{0.1f, 1.0f});
                ofFloat.setDuration(250);
                ofFloat.setInterpolator(t);
                ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(this.e, CircleView.o, new float[]{0.1f, 1.0f});
                ofFloat2.setDuration(200);
                ofFloat2.setStartDelay(200);
                ofFloat2.setInterpolator(t);
                ObjectAnimator ofFloat3 = ObjectAnimator.ofFloat(this.c, ImageView.SCALE_Y, new float[]{0.2f, 1.0f});
                ofFloat3.setDuration(350);
                ofFloat3.setStartDelay(250);
                ofFloat3.setInterpolator(v);
                ObjectAnimator ofFloat4 = ObjectAnimator.ofFloat(this.c, ImageView.SCALE_X, new float[]{0.2f, 1.0f});
                ofFloat4.setDuration(350);
                ofFloat4.setStartDelay(250);
                ofFloat4.setInterpolator(v);
                ObjectAnimator ofFloat5 = ObjectAnimator.ofFloat(this.d, DotsView.u, new float[]{0.0f, 1.0f});
                ofFloat5.setDuration(900);
                ofFloat5.setStartDelay(50);
                ofFloat5.setInterpolator(u);
                this.q.playTogether(new Animator[]{ofFloat, ofFloat2, ofFloat3, ofFloat4, ofFloat5});
                this.q.addListener(new a());
                this.q.start();
            }
        }
    }

    /* JADX WARNING: Missing block: B:10:0x0013, code skipped:
            if (r0 != 3) goto L_0x0083;
     */
    /* JADX WARNING: Missing block: B:22:0x0042, code skipped:
            if (isPressed() != r2) goto L_0x0016;
     */
    public boolean onTouchEvent(android.view.MotionEvent r6) {
        /*
        r5 = this;
        r0 = r5.p;
        r1 = 1;
        if (r0 != 0) goto L_0x0006;
    L_0x0005:
        return r1;
    L_0x0006:
        r0 = r6.getAction();
        if (r0 == 0) goto L_0x0080;
    L_0x000c:
        r2 = 0;
        if (r0 == r1) goto L_0x0045;
    L_0x000f:
        r3 = 2;
        if (r0 == r3) goto L_0x001a;
    L_0x0012:
        r6 = 3;
        if (r0 == r6) goto L_0x0016;
    L_0x0015:
        goto L_0x0083;
    L_0x0016:
        r5.setPressed(r2);
        goto L_0x0083;
    L_0x001a:
        r0 = r6.getX();
        r6 = r6.getY();
        r3 = 0;
        r4 = (r0 > r3 ? 1 : (r0 == r3 ? 0 : -1));
        if (r4 <= 0) goto L_0x003e;
    L_0x0027:
        r4 = r5.getWidth();
        r4 = (float) r4;
        r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1));
        if (r0 >= 0) goto L_0x003e;
    L_0x0030:
        r0 = (r6 > r3 ? 1 : (r6 == r3 ? 0 : -1));
        if (r0 <= 0) goto L_0x003e;
    L_0x0034:
        r0 = r5.getHeight();
        r0 = (float) r0;
        r6 = (r6 > r0 ? 1 : (r6 == r0 ? 0 : -1));
        if (r6 >= 0) goto L_0x003e;
    L_0x003d:
        r2 = 1;
    L_0x003e:
        r6 = r5.isPressed();
        if (r6 == r2) goto L_0x0083;
    L_0x0044:
        goto L_0x0016;
    L_0x0045:
        r6 = r5.c;
        r6 = r6.animate();
        r0 = 1060320051; // 0x3f333333 float:0.7 double:5.23867711E-315;
        r6 = r6.scaleX(r0);
        r6 = r6.scaleY(r0);
        r3 = 150; // 0x96 float:2.1E-43 double:7.4E-322;
        r6 = r6.setDuration(r3);
        r0 = t;
        r6.setInterpolator(r0);
        r6 = r5.c;
        r6 = r6.animate();
        r0 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r6 = r6.scaleX(r0);
        r6 = r6.scaleY(r0);
        r0 = t;
        r6.setInterpolator(r0);
        r6 = r5.isPressed();
        if (r6 == 0) goto L_0x0083;
    L_0x007c:
        r5.performClick();
        goto L_0x0016;
    L_0x0080:
        r5.setPressed(r1);
    L_0x0083:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.like.LikeButton.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void setAnimationScaleFactor(float f) {
        this.n = f;
        a();
    }

    public void setCircleEndColorRes(int i) {
        this.l = k7.a(getContext(), i);
        this.e.setEndColor(this.l);
    }

    public void setCircleStartColorInt(int i) {
        this.k = i;
        this.e.setStartColor(i);
    }

    public void setCircleStartColorRes(int i) {
        this.k = k7.a(getContext(), i);
        this.e.setStartColor(this.k);
    }

    public void setEnabled(boolean z) {
        this.p = z;
    }

    public void setIcon(lb0 lb0) {
        this.f = a(lb0);
        setLikeDrawableRes(this.f.c());
        setUnlikeDrawableRes(this.f.b());
        this.c.setImageDrawable(this.s);
    }

    public void setIconSizeDp(int i) {
        setIconSizePx((int) ob0.a(getContext(), (float) i));
    }

    public void setIconSizePx(int i) {
        this.m = i;
        a();
        this.s = ob0.a(getContext(), this.s, i, i);
        this.r = ob0.a(getContext(), this.r, i, i);
    }

    public void setLikeDrawable(Drawable drawable) {
        this.r = drawable;
        if (this.m != 0) {
            Context context = getContext();
            int i = this.m;
            this.r = ob0.a(context, drawable, i, i);
        }
        if (this.o) {
            this.c.setImageDrawable(this.r);
        }
    }

    public void setLikeDrawableRes(int i) {
        this.r = k7.c(getContext(), i);
        if (this.m != 0) {
            Context context = getContext();
            Drawable drawable = this.r;
            int i2 = this.m;
            this.r = ob0.a(context, drawable, i2, i2);
        }
        if (this.o) {
            this.c.setImageDrawable(this.r);
        }
    }

    public void setLiked(Boolean bool) {
        ImageView imageView;
        Drawable drawable;
        if (bool.booleanValue()) {
            this.o = true;
            imageView = this.c;
            drawable = this.r;
        } else {
            this.o = false;
            imageView = this.c;
            drawable = this.s;
        }
        imageView.setImageDrawable(drawable);
    }

    public void setOnAnimationEndListener(mb0 mb0) {
        this.h = mb0;
    }

    public void setOnLikeListener(nb0 nb0) {
        this.g = nb0;
    }

    public void setUnlikeDrawable(Drawable drawable) {
        this.s = drawable;
        if (this.m != 0) {
            Context context = getContext();
            int i = this.m;
            this.s = ob0.a(context, drawable, i, i);
        }
        if (!this.o) {
            this.c.setImageDrawable(this.s);
        }
    }

    public void setUnlikeDrawableRes(int i) {
        this.s = k7.c(getContext(), i);
        if (this.m != 0) {
            Context context = getContext();
            Drawable drawable = this.s;
            int i2 = this.m;
            this.s = ob0.a(context, drawable, i2, i2);
        }
        if (!this.o) {
            this.c.setImageDrawable(this.s);
        }
    }
}
