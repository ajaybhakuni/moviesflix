package com.like;

import android.animation.ArgbEvaluator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.support.v7.ob0;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;

public class CircleView extends View {
    public static final Property<CircleView, Float> o = new a(Float.class, "innerCircleRadiusProgress");
    public static final Property<CircleView, Float> p = new b(Float.class, "outerCircleRadiusProgress");
    public int c = -43230;
    public int d = -16121;
    public ArgbEvaluator e = new ArgbEvaluator();
    public Paint f = new Paint();
    public Paint g = new Paint();
    public Bitmap h;
    public Canvas i;
    public float j = 0.0f;
    public float k = 0.0f;
    public int l = 0;
    public int m = 0;
    public int n;

    public static class a extends Property<CircleView, Float> {
        public a(Class cls, String str) {
            super(cls, str);
        }

        /* renamed from: a */
        public Float get(CircleView circleView) {
            return Float.valueOf(circleView.getInnerCircleRadiusProgress());
        }

        /* renamed from: a */
        public void set(CircleView circleView, Float f) {
            circleView.setInnerCircleRadiusProgress(f.floatValue());
        }
    }

    public static class b extends Property<CircleView, Float> {
        public b(Class cls, String str) {
            super(cls, str);
        }

        /* renamed from: a */
        public Float get(CircleView circleView) {
            return Float.valueOf(circleView.getOuterCircleRadiusProgress());
        }

        /* renamed from: a */
        public void set(CircleView circleView, Float f) {
            circleView.setOuterCircleRadiusProgress(f.floatValue());
        }
    }

    public CircleView(Context context) {
        super(context);
        a();
    }

    public CircleView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a();
    }

    public CircleView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        a();
    }

    public final void a() {
        this.f.setStyle(Style.FILL);
        this.g.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
    }

    public void a(int i, int i2) {
        this.l = i;
        this.m = i2;
        invalidate();
    }

    public final void b() {
        this.f.setColor(((Integer) this.e.evaluate((float) ob0.a((double) ((float) ob0.a((double) this.j, 0.5d, 1.0d)), 0.5d, 1.0d, 0.0d, 1.0d), Integer.valueOf(this.c), Integer.valueOf(this.d))).intValue());
    }

    public float getInnerCircleRadiusProgress() {
        return this.k;
    }

    public float getOuterCircleRadiusProgress() {
        return this.j;
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.i.drawColor(16777215, Mode.CLEAR);
        this.i.drawCircle((float) (getWidth() / 2), (float) (getHeight() / 2), this.j * ((float) this.n), this.f);
        this.i.drawCircle((float) (getWidth() / 2), (float) (getHeight() / 2), this.k * ((float) this.n), this.g);
        canvas.drawBitmap(this.h, 0.0f, 0.0f, null);
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        i = this.l;
        if (i != 0) {
            i2 = this.m;
            if (i2 != 0) {
                setMeasuredDimension(i, i2);
            }
        }
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.n = i / 2;
        this.h = Bitmap.createBitmap(getWidth(), getWidth(), Config.ARGB_8888);
        this.i = new Canvas(this.h);
    }

    public void setEndColor(int i) {
        this.d = i;
        invalidate();
    }

    public void setInnerCircleRadiusProgress(float f) {
        this.k = f;
        postInvalidate();
    }

    public void setOuterCircleRadiusProgress(float f) {
        this.j = f;
        b();
        postInvalidate();
    }

    public void setStartColor(int i) {
        this.c = i;
        invalidate();
    }
}
