package com.like;

import android.animation.ArgbEvaluator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.support.v7.ob0;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;

public class DotsView extends View {
    public static final Property<DotsView, Float> u = new a(Float.class, "dotsProgress");
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;
    public int h;
    public final Paint[] i;
    public int j;
    public int k;
    public float l;
    public float m;
    public float n;
    public float o;
    public float p;
    public float q;
    public float r;
    public float s;
    public ArgbEvaluator t;

    public static class a extends Property<DotsView, Float> {
        public a(Class cls, String str) {
            super(cls, str);
        }

        /* renamed from: a */
        public Float get(DotsView dotsView) {
            return Float.valueOf(dotsView.getCurrentProgress());
        }

        /* renamed from: a */
        public void set(DotsView dotsView, Float f) {
            dotsView.setCurrentProgress(f.floatValue());
        }
    }

    public DotsView(Context context) {
        super(context);
        this.c = -16121;
        this.d = -26624;
        this.e = -43230;
        this.f = -769226;
        this.g = 0;
        this.h = 0;
        this.i = new Paint[4];
        this.o = 0.0f;
        this.p = 0.0f;
        this.q = 0.0f;
        this.r = 0.0f;
        this.s = 0.0f;
        this.t = new ArgbEvaluator();
        a();
    }

    public DotsView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.c = -16121;
        this.d = -26624;
        this.e = -43230;
        this.f = -769226;
        this.g = 0;
        this.h = 0;
        this.i = new Paint[4];
        this.o = 0.0f;
        this.p = 0.0f;
        this.q = 0.0f;
        this.r = 0.0f;
        this.s = 0.0f;
        this.t = new ArgbEvaluator();
        a();
    }

    public DotsView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.c = -16121;
        this.d = -26624;
        this.e = -43230;
        this.f = -769226;
        this.g = 0;
        this.h = 0;
        this.i = new Paint[4];
        this.o = 0.0f;
        this.p = 0.0f;
        this.q = 0.0f;
        this.r = 0.0f;
        this.s = 0.0f;
        this.t = new ArgbEvaluator();
        a();
    }

    public final void a() {
        int i = 0;
        while (true) {
            Paint[] paintArr = this.i;
            if (i < paintArr.length) {
                paintArr[i] = new Paint();
                this.i[i].setStyle(Style.FILL);
                i++;
            } else {
                return;
            }
        }
    }

    public void a(int i, int i2) {
        this.c = i;
        this.d = i2;
        this.e = i;
        this.f = i2;
        invalidate();
    }

    public final void a(Canvas canvas) {
        int i = 0;
        while (i < 7) {
            double d = (double) this.j;
            double d2 = (double) this.s;
            double d3 = (double) ((i * 51) - 10);
            Double.isNaN(d3);
            d3 = (d3 * 3.141592653589793d) / 180.0d;
            double cos = Math.cos(d3);
            Double.isNaN(d2);
            d2 *= cos;
            Double.isNaN(d);
            int i2 = (int) (d + d2);
            double d4 = (double) this.k;
            cos = (double) this.s;
            double sin = Math.sin(d3);
            Double.isNaN(cos);
            cos *= sin;
            Double.isNaN(d4);
            float f = (float) i2;
            float f2 = (float) ((int) (d4 + cos));
            float f3 = this.r;
            Paint[] paintArr = this.i;
            i++;
            canvas.drawCircle(f, f2, f3, paintArr[i % paintArr.length]);
        }
    }

    public final void b() {
        int a = (int) ob0.a((double) ((float) ob0.a((double) this.o, 0.6000000238418579d, 1.0d)), 0.6000000238418579d, 1.0d, 255.0d, 0.0d);
        this.i[0].setAlpha(a);
        this.i[1].setAlpha(a);
        this.i[2].setAlpha(a);
        this.i[3].setAlpha(a);
    }

    public void b(int i, int i2) {
        this.g = i;
        this.h = i2;
        invalidate();
    }

    public final void b(Canvas canvas) {
        for (int i = 0; i < 7; i++) {
            double d = (double) this.j;
            double d2 = (double) this.p;
            double d3 = (double) (i * 51);
            Double.isNaN(d3);
            d3 = (d3 * 3.141592653589793d) / 180.0d;
            double cos = Math.cos(d3);
            Double.isNaN(d2);
            d2 *= cos;
            Double.isNaN(d);
            int i2 = (int) (d + d2);
            double d4 = (double) this.k;
            cos = (double) this.p;
            double sin = Math.sin(d3);
            Double.isNaN(cos);
            cos *= sin;
            Double.isNaN(d4);
            float f = (float) i2;
            float f2 = (float) ((int) (d4 + cos));
            float f3 = this.q;
            Paint[] paintArr = this.i;
            canvas.drawCircle(f, f2, f3, paintArr[i % paintArr.length]);
        }
    }

    public final void c() {
        Paint paint;
        ArgbEvaluator argbEvaluator;
        Object valueOf;
        int i;
        float f = this.o;
        if (f < 0.5f) {
            f = (float) ob0.a((double) f, 0.0d, 0.5d, 0.0d, 1.0d);
            this.i[0].setColor(((Integer) this.t.evaluate(f, Integer.valueOf(this.c), Integer.valueOf(this.d))).intValue());
            this.i[1].setColor(((Integer) this.t.evaluate(f, Integer.valueOf(this.d), Integer.valueOf(this.e))).intValue());
            this.i[2].setColor(((Integer) this.t.evaluate(f, Integer.valueOf(this.e), Integer.valueOf(this.f))).intValue());
            paint = this.i[3];
            argbEvaluator = this.t;
            valueOf = Integer.valueOf(this.f);
            i = this.c;
        } else {
            f = (float) ob0.a((double) f, 0.5d, 1.0d, 0.0d, 1.0d);
            this.i[0].setColor(((Integer) this.t.evaluate(f, Integer.valueOf(this.d), Integer.valueOf(this.e))).intValue());
            this.i[1].setColor(((Integer) this.t.evaluate(f, Integer.valueOf(this.e), Integer.valueOf(this.f))).intValue());
            this.i[2].setColor(((Integer) this.t.evaluate(f, Integer.valueOf(this.f), Integer.valueOf(this.c))).intValue());
            paint = this.i[3];
            argbEvaluator = this.t;
            valueOf = Integer.valueOf(this.c);
            i = this.d;
        }
        paint.setColor(((Integer) argbEvaluator.evaluate(f, valueOf, Integer.valueOf(i))).intValue());
    }

    public final void d() {
        float f = this.o;
        this.s = f < 0.3f ? (float) ob0.a((double) f, 0.0d, 0.30000001192092896d, 0.0d, (double) this.m) : this.m;
        f = this.o;
        if (f == 0.0f) {
            this.r = 0.0f;
            return;
        }
        if (((double) f) < 0.2d) {
            f = this.n;
        } else {
            double a;
            if (((double) f) < 0.5d) {
                double d = (double) f;
                f = this.n;
                double d2 = (double) f;
                double d3 = (double) f;
                Double.isNaN(d3);
                a = ob0.a(d, 0.20000000298023224d, 0.5d, d2, d3 * 0.3d);
            } else {
                a = ob0.a((double) f, 0.5d, 1.0d, (double) (this.n * 0.3f), 0.0d);
            }
            f = (float) a;
        }
        this.r = f;
    }

    public final void e() {
        double a;
        float f = this.o;
        if (f < 0.3f) {
            a = ob0.a((double) f, 0.0d, 0.30000001192092896d, 0.0d, (double) (this.l * 0.8f));
        } else {
            double d = (double) f;
            f = this.l;
            a = ob0.a(d, 0.30000001192092896d, 1.0d, (double) (0.8f * f), (double) f);
        }
        this.p = (float) a;
        f = this.o;
        if (f == 0.0f) {
            this.q = 0.0f;
        } else {
            this.q = ((double) f) < 0.7d ? this.n : (float) ob0.a((double) f, 0.699999988079071d, 1.0d, (double) this.n, 0.0d);
        }
    }

    public float getCurrentProgress() {
        return this.o;
    }

    public void onDraw(Canvas canvas) {
        b(canvas);
        a(canvas);
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        i = this.g;
        if (i != 0) {
            i2 = this.h;
            if (i2 != 0) {
                setMeasuredDimension(i, i2);
            }
        }
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        i /= 2;
        this.j = i;
        this.k = i2 / 2;
        this.n = 5.0f;
        this.l = ((float) i) - (this.n * 2.0f);
        this.m = this.l * 0.8f;
    }

    public void setCurrentProgress(float f) {
        this.o = f;
        d();
        e();
        c();
        b();
        postInvalidate();
    }
}
