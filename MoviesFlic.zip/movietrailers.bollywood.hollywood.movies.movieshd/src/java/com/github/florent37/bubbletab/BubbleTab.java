package com.github.florent37.bubbletab;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.support.v7.yj;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.j;
import java.util.ArrayList;
import java.util.List;

public class BubbleTab extends LinearLayout {
    public int c = 0;
    public ViewPager d;
    public int e;
    public c f = new c();
    public d g;
    public List<View> h;
    public final j i = new a();

    public class a implements j {
        public float a;
        public boolean b;

        public void a(int i) {
        }

        public void a(int i, float f, int i2) {
            int width;
            float f2 = this.a;
            if (f2 == 0.0f) {
                this.b = f > f2;
            }
            BubbleTab bubbleTab = BubbleTab.this;
            if (bubbleTab.e == 0 && bubbleTab.c != 0) {
                width = bubbleTab.getWidth();
                BubbleTab bubbleTab2 = BubbleTab.this;
                bubbleTab.e = width / bubbleTab2.c;
                bubbleTab2.f.b(BubbleTab.this.e);
            }
            bubbleTab = BubbleTab.this;
            width = bubbleTab.e;
            bubbleTab.f.c(((float) (i * width)) + (((float) width) * f));
            BubbleTab.this.f.b((1.0f * (Math.abs(f - 0.5f) + 0.5f)) + 0.0f);
            if (f != 0.0f) {
                List b;
                i2 = (f > 0.5f ? 1 : (f == 0.5f ? 0 : -1));
                if (this.b) {
                    if (i2 < 0) {
                        ((View) BubbleTab.this.h.get(i)).setSelected(true);
                        i++;
                        bubbleTab = BubbleTab.this;
                        if (i < bubbleTab.c) {
                            b = bubbleTab.h;
                        }
                    } else {
                        ((View) BubbleTab.this.h.get(i)).setSelected(false);
                        i++;
                        bubbleTab = BubbleTab.this;
                        if (i < bubbleTab.c) {
                            b = bubbleTab.h;
                            ((View) b.get(i)).setSelected(true);
                        }
                    }
                } else if (i2 < 0) {
                    ((View) BubbleTab.this.h.get(i)).setSelected(true);
                    if (i - 1 > 0) {
                        b = BubbleTab.this.h;
                        i++;
                    }
                } else {
                    ((View) BubbleTab.this.h.get(i)).setSelected(false);
                    if (i - 1 > 0) {
                        b = BubbleTab.this.h;
                        i++;
                        ((View) b.get(i)).setSelected(true);
                    }
                }
                ((View) b.get(i)).setSelected(false);
            }
            this.a = f;
            BubbleTab.this.postInvalidate();
        }

        public void b(int i) {
        }
    }

    public class b implements OnClickListener {
        public final /* synthetic */ int c;

        public b(int i) {
            this.c = i;
        }

        public void onClick(View view) {
            ViewPager viewPager = BubbleTab.this.d;
            if (viewPager != null) {
                viewPager.a(this.c, true);
            }
        }
    }

    public static class c {
        public Paint a = new Paint();
        public float b = 1.0f;
        public int c;
        public float d = 1.0f;
        public float e = 1.0f;

        public c() {
            this.a.setColor(-16777216);
            this.a.setAntiAlias(true);
            this.a.setStrokeWidth(1.0f);
            this.a.setStyle(Style.FILL_AND_STROKE);
        }

        public void a(float f) {
            this.d = f;
        }

        public void a(int i) {
            this.a.setColor(i);
        }

        public void a(Canvas canvas) {
            canvas.save();
            canvas.translate(this.b, 0.0f);
            int height = canvas.getHeight();
            int i = this.c;
            canvas.drawCircle(((float) i) / 2.0f, ((float) height) / 2.0f, ((((float) i) / 2.0f) * this.d) * this.e, this.a);
            canvas.restore();
        }

        public void b(float f) {
            this.e = f;
        }

        public void b(int i) {
            this.c = i;
        }

        public void c(float f) {
            this.b = f;
        }
    }

    public static class d {
        public int a;
        public float b;
        public List<Integer> c = new ArrayList();
        public int d;

        public d(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, yj.BubbleTab);
            if (obtainStyledAttributes != null) {
                obtainStyledAttributes.getColor(yj.BubbleTab_bubbleTab_selectedColor, -1);
                obtainStyledAttributes.getColor(yj.BubbleTab_bubbleTab_unselectedColor, Color.parseColor("#c0c0c0"));
                this.a = obtainStyledAttributes.getInt(yj.BubbleTab_bubbleTab_circleColor, -16777216);
                this.b = obtainStyledAttributes.getFloat(yj.BubbleTab_bubbleTab_circleRatio, 1.2f);
                this.d = obtainStyledAttributes.getResourceId(yj.BubbleTab_bubbleTab_image0Colored, 0);
                a(obtainStyledAttributes, yj.BubbleTab_bubbleTab_image0);
                a(obtainStyledAttributes, yj.BubbleTab_bubbleTab_image1);
                a(obtainStyledAttributes, yj.BubbleTab_bubbleTab_image2);
                a(obtainStyledAttributes, yj.BubbleTab_bubbleTab_image3);
                a(obtainStyledAttributes, yj.BubbleTab_bubbleTab_image4);
                a(obtainStyledAttributes, yj.BubbleTab_bubbleTab_image5);
                a(obtainStyledAttributes, yj.BubbleTab_bubbleTab_image6);
                a(obtainStyledAttributes, yj.BubbleTab_bubbleTab_image7);
                a(obtainStyledAttributes, yj.BubbleTab_bubbleTab_image8);
                a(obtainStyledAttributes, yj.BubbleTab_bubbleTab_image9);
                a(obtainStyledAttributes, yj.BubbleTab_bubbleTab_image10);
                obtainStyledAttributes.recycle();
                int i = this.d;
            }
        }

        public final void a(TypedArray typedArray, int i) {
            int resourceId = typedArray.getResourceId(i, 0);
            if (resourceId != 0) {
                this.c.add(Integer.valueOf(resourceId));
            }
        }
    }

    public BubbleTab(Context context) {
        super(context);
        a(context, null);
    }

    public BubbleTab(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a(context, attributeSet);
    }

    public BubbleTab(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        a(context, attributeSet);
    }

    public final void a(Context context, AttributeSet attributeSet) {
        setWillNotDraw(false);
        this.g = new d(context, attributeSet);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ViewPager viewPager = this.d;
        if (viewPager != null) {
            viewPager.b(this.i);
        }
    }

    public void onDraw(Canvas canvas) {
        this.f.a(canvas);
        super.onDraw(canvas);
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        this.f.a(this.g.a);
        this.f.a(this.g.b);
        this.c = getChildCount();
        this.h = new ArrayList();
        for (int i = 0; i < this.c; i++) {
            View childAt = getChildAt(i);
            this.h.add(childAt);
            childAt.setOnClickListener(new b(i));
        }
    }

    public void setupWithViewPager(ViewPager viewPager) {
        this.d = viewPager;
        viewPager.a(this.i);
        int currentItem = viewPager.getCurrentItem();
        int i = 0;
        while (i < this.h.size()) {
            ((View) this.h.get(i)).setSelected(i == currentItem);
            i++;
        }
        this.f.c((float) (this.e * currentItem));
        postInvalidate();
    }
}
